(async function () {
  'use strict';
  const { el, api } = UI;
  const $ = (s) => document.querySelector(s);
  let state = await UI.loadState();

  function render() {
    const { settings } = state;
    const active = SKT.resolveTheme(state);
    $('#enabled').checked = settings.enabled;
    document.body.classList.toggle('off', !settings.enabled);
    $('#status').textContent = settings.enabled ? `Aktiv: ${active.name}` : 'Ausgeschaltet – Original-Design';

    const groups = SKT.allThemes(state);
    const root = $('#themes');
    root.textContent = '';
    for (const [title, list] of [['Vorlagen', groups.presets], ['Eigene', groups.user], ['Aus Quellen', groups.sources]]) {
      if (!list.length) continue;
      root.append(
        el('div', { class: 'group-title', text: title }),
        el('div', { class: 'grid' }, list.map((t) => card(t, t.id === active.id && settings.enabled)))
      );
    }
  }

  function card(theme, isActive) {
    return el(
      'button',
      {
        class: `tcard${isActive ? ' active' : ''}`,
        title: theme.description || theme.name,
        'aria-pressed': String(isActive),
        onclick: () => activate(theme.id),
      },
      UI.mini(theme),
      el('div', { class: 'name' }, isActive ? el('i', { class: 'dot' }) : null, el('span', { text: theme.name }))
    );
  }

  async function activate(id) {
    state.settings = { ...state.settings, activeThemeId: id, enabled: true };
    render();
    await UI.saveSettings(state.settings);
  }

  $('#enabled').addEventListener('change', async (e) => {
    state.settings = { ...state.settings, enabled: e.target.checked };
    render();
    await UI.saveSettings(state.settings);
  });

  const openEditor = (hash) => {
    api.tabs.create({ url: api.runtime.getURL(`ui/options.html${hash}`) });
    window.close();
  };
  $('#edit').addEventListener('click', () => openEditor(`#edit=${encodeURIComponent(SKT.resolveTheme(state).id)}`));
  $('#import').addEventListener('click', () => openEditor('#import'));

  api.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'local' || !(changes.settings || changes.userThemes || changes.sourceThemes)) return;
    state = await UI.loadState();
    render();
  });

  render();
})();
