(async function () {
  'use strict';
  const { el, api, toast } = UI;
  const $ = (s) => document.querySelector(s);
  const SKRIME_TABS = ['https://skrime.eu/*', 'https://*.skrime.eu/*'];
  const FONTS = [
    'Inter', 'Poppins', 'Montserrat', 'Outfit', 'Plus Jakarta Sans', 'Manrope', 'DM Sans', 'Space Grotesk',
    'Sora', 'Lexend', 'Rubik', 'Roboto', 'Open Sans', 'Lato', 'Nunito', 'Ubuntu', 'JetBrains Mono', 'Fira Code',
  ];

  let state = await UI.loadState();
  let current = null; // Arbeitskopie des Themes im Editor
  let original = null; // Stand beim Laden (für "verwerfen" und Reset-Knöpfe)
  let selectedId = null;

  const clone = (o) => JSON.parse(JSON.stringify(o));
  const findTheme = (id) => state.userThemes[id] || state.sourceThemes[id] || SKT.PRESETS.find((p) => p.id === id);
  const isDirty = () => !!current && JSON.stringify(current) !== JSON.stringify(original);
  const isUserTheme = (t) => t?.kind === 'user' && t.id?.startsWith('user:') && !!state.userThemes[t.id];
  const newUserId = (name) => `user:${SKT.slug(name)}-${Date.now().toString(36)}`;

  // ------------------------------------------------------------------ Tabs

  function showTab(name) {
    document.querySelectorAll('.tabs [data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
    document.querySelectorAll('.tab').forEach((s) => (s.hidden = s.id !== `tab-${name}`));
    if (name === 'settings') {
      updateCacheInfo();
      renderDashboardSettings();
    }
    schedulePreview();
  }
  document.querySelectorAll('.tabs [data-tab]').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

  // ------------------------------------------------------------ Theme-Liste

  function swatches(theme) {
    const c = theme.colors;
    return el('span', { class: 'swatches', 'aria-hidden': 'true' },
      [c.background, c.surface, c.primary, c.accent].map((v) => el('i', { style: `background:${v}` })));
  }

  function renderList() {
    const active = SKT.resolveTheme(state);
    const groups = SKT.allThemes(state);
    const root = $('#themeList');
    root.textContent = '';
    const unsavedNew = current && !current.id;
    for (const [title, list] of [['Vorlagen', groups.presets], ['Eigene', groups.user], ['Aus Quellen', groups.sources]]) {
      if (!list.length && !(title === 'Eigene' && unsavedNew)) continue;
      root.append(el('div', { class: 'list-title', text: title }));
      if (title === 'Eigene' && unsavedNew) {
        root.append(el('button', { class: 'list-item selected' }, swatches(current), el('span', { class: 'li-name', text: current.name || 'Neues Theme' }), el('span', { class: 'badge warn', text: 'neu' })));
      }
      for (const t of list) {
        const isActive = state.settings.enabled && t.id === active.id;
        root.append(
          el('button', { class: `list-item${t.id === selectedId ? ' selected' : ''}`, onclick: () => select(t.id) },
            swatches(t),
            el('span', { class: 'li-name', text: t.name }),
            isActive ? el('span', { class: 'badge active', text: 'aktiv' }) : null)
        );
      }
    }
  }

  // ---------------------------------------------------------------- Editor

  function select(id, { force = false } = {}) {
    if (!force && isDirty() && !confirm('Ungespeicherte Änderungen verwerfen?')) return;
    const theme = findTheme(id);
    if (!theme) return;
    selectedId = id;
    load(clone(theme));
    showTab('editor');
    history.replaceState(null, '', `#edit=${encodeURIComponent(id)}`);
  }

  function load(theme) {
    current = theme;
    original = clone(theme);
    fillForm();
    changed();
  }

  function buildColorFields() {
    const root = $('#colorFields');
    for (const role of SKT.ROLES) {
      const id = `c-${role}`;
      const picker = el('input', { type: 'color', id, 'aria-label': SKT.ROLE_LABELS[role] });
      const hex = el('input', { type: 'text', class: 'hex', maxlength: '7', spellcheck: 'false', 'aria-label': `${SKT.ROLE_LABELS[role]} (Hex)` });
      const reset = el('button', { class: 'reset', type: 'button', title: 'Zurücksetzen', text: '↺' });
      const row = el('div', { class: 'color-field', 'data-role': role }, picker, hex, el('label', { for: id, text: SKT.ROLE_LABELS[role] }), reset);

      const setColor = (value) => {
        current.colors[role] = value;
        picker.value = value;
        hex.value = value;
        hex.classList.remove('invalid');
        changed();
      };
      picker.addEventListener('input', () => setColor(picker.value));
      hex.addEventListener('input', () => {
        const v = SKT.normalizeHex(hex.value.startsWith('#') ? hex.value : `#${hex.value}`);
        if (v && /^#?[0-9a-f]{6}$/i.test(hex.value.trim())) setColor(v);
        else hex.classList.toggle('invalid', !v);
      });
      hex.addEventListener('blur', () => {
        hex.value = current.colors[role];
        hex.classList.remove('invalid');
      });
      reset.addEventListener('click', () => setColor(original.colors[role]));
      root.append(row);
    }
  }

  function fillForm() {
    const t = current;
    $('#name').value = t.name;
    $('#author').value = t.author || '';
    $('#description').value = t.description || '';
    $('#font').value = t.font || '';
    $('#tintImages').checked = t.tintImages !== false;
    $('#css').value = t.css || '';
    for (const role of SKT.ROLES) {
      const row = document.querySelector(`.color-field[data-role="${role}"]`);
      row.querySelector('input[type=color]').value = t.colors[role];
      row.querySelector('.hex').value = t.colors[role];
    }

    $('#kindBadge').textContent = t.id ? UI.kindLabel(t) : 'Neu';
    const hint = $('#readonlyHint');
    if (t.kind === 'preset') hint.textContent = 'Vorlage – Änderungen werden als eigenes Theme gespeichert.';
    else if (t.kind === 'source') hint.textContent = `Aus der Quelle ${t.source} – Änderungen werden als eigenes Theme gespeichert. Die Quelle selbst wird automatisch aktualisiert.`;
    else hint.textContent = '';

    const blocked = !!t.blockedCss;
    $('#blockedBox').hidden = !blocked;
    if (blocked) {
      $('#blockedReason').textContent = t.blockedReason;
      $('#blockedCss').textContent = t.blockedCss;
    }
    $('#delete').hidden = !isUserTheme(t);
  }

  function changed() {
    const dirty = isDirty();
    $('#dirtyBadge').hidden = !dirty;
    $('#revert').disabled = !dirty;
    const isActive = state.settings.enabled && SKT.resolveTheme(state).id === current.id;
    $('#activate').textContent = dirty ? 'Speichern & aktivieren' : isActive ? 'Aktiv' : 'Aktivieren';
    $('#activate').disabled = !dirty && isActive;
    $('#save').textContent = isUserTheme(current) || !current.id ? 'Speichern' : 'Als eigenes Theme speichern';
    $('#save').disabled = !dirty && isUserTheme(current);

    for (const row of document.querySelectorAll('.color-field')) {
      const role = row.dataset.role;
      row.classList.toggle('changed', current.colors[role] !== original.colors[role]);
    }
    updateMock();
    updateContrastHints();
    renderList();
    schedulePreview();
  }

  function updateMock() {
    const mock = $('#mock');
    UI.applyThemeVars(mock, current.colors);
    mock.style.setProperty('--m-font', current.font ? `"${current.font}"` : "'Nunito'");
    let link = document.getElementById('mock-font');
    if (current.fontUrl) {
      if (!link) {
        link = el('link', { id: 'mock-font', rel: 'stylesheet' });
        document.head.append(link);
      }
      if (link.getAttribute('href') !== current.fontUrl) link.href = current.fontUrl;
    } else link?.remove();
  }

  function updateContrastHints() {
    const c = current.colors;
    const hints = [];
    const cr = (a, b) => SKT.contrast(a, b);
    const fmt = (v) => v.toFixed(1).replace('.', ',');
    if (cr(c.primary, '#ffffff') < 3) hints.push(`Weißer Button-Text auf der Primärfarbe ist schwer lesbar (Kontrast ${fmt(cr(c.primary, '#ffffff'))}:1, empfohlen ≥ 3:1).`);
    if (cr(c.text, c.background) < 4.5) hints.push(`Text auf Hintergrund hat wenig Kontrast (${fmt(cr(c.text, c.background))}:1, empfohlen ≥ 4,5:1).`);
    if (cr(c.muted, c.surface) < 3) hints.push(`Gedämpfter Text auf Flächen ist kaum lesbar (${fmt(cr(c.muted, c.surface))}:1).`);
    if (SKT.rgbToOklch(SKT.parseHex(c.background)).L > 0.6)
      hints.push('Helle Hintergründe werden nur eingeschränkt unterstützt – skrime.eu liefert ausschließlich ein Dark-Theme mit fest weißen Überschriften.');
    const root = $('#contrastHints');
    root.textContent = '';
    for (const h of hints) root.append(el('div', { class: 'contrast', text: h }));
  }

  // Formular -> Arbeitskopie
  $('#name').addEventListener('input', (e) => { current.name = e.target.value.slice(0, 60); changed(); });
  $('#author').addEventListener('input', (e) => { current.author = e.target.value; changed(); });
  $('#description').addEventListener('input', (e) => { current.description = e.target.value; changed(); });
  $('#tintImages').addEventListener('change', (e) => { current.tintImages = e.target.checked; changed(); });
  $('#css').addEventListener('input', (e) => { current.css = e.target.value; changed(); });
  $('#font').addEventListener('input', (e) => {
    current.font = e.target.value.replace(/[^\w \-]/g, '').trim();
    current.fontUrl = SKT.fontUrlFor(current.font);
    changed();
  });
  $('#css').addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    e.preventDefault();
    const ta = e.target;
    ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end');
    ta.dispatchEvent(new Event('input'));
  });

  // ----------------------------------------------------------- Speichern

  async function save({ activate = false } = {}) {
    if (!current.name.trim()) current.name = 'Unbenanntes Theme';
    const wasActive = SKT.resolveTheme(state).id === current.id;
    let theme = clone(current);
    if (!isUserTheme(theme)) {
      const source = findTheme(selectedId);
      const name = source && source.name === theme.name ? `${theme.name} (eigene)` : theme.name;
      theme = { ...theme, id: newUserId(name), name };
      delete theme.source;
    }
    const saved = SKT.normalizeTheme(theme, { kind: 'user' });
    if (theme.blockedCss) {
      saved.blockedCss = theme.blockedCss;
      saved.blockedReason = theme.blockedReason;
    }
    state.userThemes[saved.id] = saved;
    const update = { userThemes: state.userThemes };
    if (activate || wasActive) {
      state.settings = { ...state.settings, activeThemeId: saved.id, enabled: activate ? true : state.settings.enabled };
      update.settings = state.settings;
    }
    await api.storage.local.set(update);
    selectedId = saved.id;
    load(clone(saved));
    history.replaceState(null, '', `#edit=${encodeURIComponent(saved.id)}`);
    toast(activate ? 'Gespeichert & aktiviert' : 'Gespeichert');
  }

  $('#save').addEventListener('click', () => save().catch((e) => toast(e.message, 'error')));

  $('#activate').addEventListener('click', async () => {
    if (isDirty() || !current.id) return save({ activate: true }).catch((e) => toast(e.message, 'error'));
    state.settings = { ...state.settings, activeThemeId: current.id, enabled: true };
    await UI.saveSettings(state.settings);
    changed();
    toast(`„${current.name}“ ist jetzt aktiv`);
  });

  $('#revert').addEventListener('click', () => {
    load(clone(original));
  });

  $('#duplicate').addEventListener('click', () => {
    if (isDirty() && !confirm('Ungespeicherte Änderungen werden in die Kopie übernommen. Fortfahren?')) return;
    const copy = clone(current);
    copy.id = '';
    copy.kind = 'user';
    copy.name = `${current.name} Kopie`.slice(0, 60);
    delete copy.source;
    selectedId = null;
    current = copy;
    original = clone(copy);
    original.name = ''; // gilt als ungespeichert
    fillForm();
    changed();
    $('#name').focus();
  });

  $('#newTheme').addEventListener('click', () => {
    if (isDirty() && !confirm('Ungespeicherte Änderungen verwerfen?')) return;
    const base = SKT.resolveTheme(state);
    selectedId = null;
    current = { id: '', name: 'Mein Theme', author: '', description: '', kind: 'user', colors: { ...base.colors }, font: base.font || '', fontUrl: base.fontUrl || '', tintImages: true, css: '' };
    original = { ...clone(current), name: '' };
    fillForm();
    changed();
    showTab('editor');
    $('#name').select();
  });

  $('#delete').addEventListener('click', async () => {
    if (!isUserTheme(current) || !confirm(`„${current.name}“ wirklich löschen?`)) return;
    delete state.userThemes[current.id];
    const update = { userThemes: state.userThemes };
    if (state.settings.activeThemeId === current.id) {
      state.settings = { ...state.settings, activeThemeId: SKT.DEFAULT_THEME_ID };
      update.settings = state.settings;
    }
    await api.storage.local.set(update);
    toast('Theme gelöscht');
    select(SKT.resolveTheme(state).id, { force: true });
  });

  function download(filename, data) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    el('a', { href: url, download: filename }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  $('#exportFile').addEventListener('click', () => download(`${SKT.slug(current.name)}.skrime-theme.json`, SKT.exportTheme(current)));
  $('#copyJson').addEventListener('click', async () => {
    await navigator.clipboard.writeText(JSON.stringify(SKT.exportTheme(current), null, 2));
    toast('JSON in die Zwischenablage kopiert');
  });

  $('#approveCss').addEventListener('click', async () => {
    const css = current.blockedCss;
    if (!css) return;
    if (current.kind === 'source' && state.sourceThemes[current.id]) {
      // Freigabe merken (gilt nur, solange sich das CSS der Quelle nicht ändert)
      state.approvedCss[current.id] = SKT.hash(css);
      const stored = state.sourceThemes[current.id];
      stored.css = css;
      delete stored.blockedCss;
      delete stored.blockedReason;
      await api.storage.local.set({ approvedCss: state.approvedCss, sourceThemes: state.sourceThemes });
      load(clone(stored));
    } else {
      current.css = css;
      delete current.blockedCss;
      delete current.blockedReason;
      fillForm();
      changed();
    }
    toast('CSS freigegeben');
  });

  // -------------------------------------------------- Live-Vorschau in Tabs

  const ports = new Map();
  let previewTimer;

  function schedulePreview() {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(pushPreview, 50);
  }

  // Vorschau nur, solange der Editor sichtbar ist – sonst gilt das gespeicherte Theme.
  async function pushPreview() {
    const editorVisible = !$('#tab-editor').hidden;
    const theme = state.settings.livePreview && current && editorVisible ? SKT.normalizeTheme(current, { kind: current.kind || 'user' }) : null;
    let tabs = [];
    try {
      tabs = await api.tabs.query({ url: SKRIME_TABS });
    } catch {
      return;
    }
    for (const tab of tabs) {
      let port = ports.get(tab.id);
      if (!port) {
        try {
          port = api.tabs.connect(tab.id, { name: 'skt-preview' });
        } catch {
          continue;
        }
        ports.set(tab.id, port);
        port.onDisconnect.addListener(() => {
          void api.runtime.lastError;
          if (ports.get(tab.id) === port) ports.delete(tab.id);
        });
      }
      try {
        port.postMessage({ theme });
      } catch {
        ports.delete(tab.id);
      }
    }
  }

  api.tabs.onUpdated.addListener((_id, info) => {
    if (info.status === 'complete') schedulePreview();
  });

  $('#livePreview').addEventListener('change', async (e) => {
    state.settings = { ...state.settings, livePreview: e.target.checked };
    await UI.saveSettings(state.settings);
    schedulePreview();
  });

  $('#enabled').addEventListener('change', async (e) => {
    state.settings = { ...state.settings, enabled: e.target.checked };
    await UI.saveSettings(state.settings);
    changed();
  });

  window.addEventListener('beforeunload', (e) => {
    if (isDirty()) e.preventDefault();
  });

  // ----------------------------------------------------------------- Import

  async function requestOrigin(url) {
    try {
      return await api.permissions.request({ origins: [`${url.protocol}//${url.hostname}/*`] });
    } catch {
      return false;
    }
  }

  async function addUserThemes(themes) {
    const added = [];
    for (const t of themes) {
      const theme = { ...t, id: newUserId(t.name), kind: 'user' };
      state.userThemes[theme.id] = theme;
      added.push(theme);
    }
    await api.storage.local.set({ userThemes: state.userThemes });
    return added;
  }

  function showImported(themes) {
    const root = $('#importResult');
    root.textContent = '';
    for (const t of themes) {
      root.append(
        el('div', { class: 'result-card' },
          UI.mini(t),
          el('div', { class: 'rc-name' }, el('span', { text: t.name }), t.blockedCss ? el('span', { class: 'badge warn', text: 'CSS blockiert', title: 'Eigenes CSS wurde zur Prüfung zurückgehalten' }) : null),
          el('div', { class: 'rc-actions' },
            el('button', { class: 'btn small primary', text: 'Aktivieren', onclick: async () => {
              state.settings = { ...state.settings, activeThemeId: t.id, enabled: true };
              await UI.saveSettings(state.settings);
              renderList();
              toast(`„${t.name}“ ist jetzt aktiv`);
            } }),
            el('button', { class: 'btn small', text: 'Bearbeiten', onclick: () => select(t.id) })))
      );
    }
  }

  function reportImport(themes, errors = []) {
    const blocked = themes.filter((t) => t.blockedCss).length;
    let msg = `${themes.length} Theme${themes.length === 1 ? '' : 's'} importiert`;
    if (blocked) msg += ` – bei ${blocked} wurde CSS zur Prüfung zurückgehalten`;
    if (errors.length) msg += ` (${errors.length} fehlerhaft übersprungen)`;
    toast(msg);
  }

  $('#importUrlBtn').addEventListener('click', async () => {
    let url;
    try {
      url = new URL($('#importUrl').value.trim());
      if (!/^https?:$/.test(url.protocol)) throw new Error();
    } catch {
      return toast('Bitte eine gültige http(s)-URL eingeben', 'error');
    }
    // Muss direkt im Klick-Handler passieren (Nutzergeste).
    if (!(await requestOrigin(url))) return toast(`Zugriff auf ${url.hostname} wurde nicht erlaubt`, 'error');
    const btn = $('#importUrlBtn');
    btn.disabled = true;
    btn.textContent = 'Lädt…';
    try {
      if ($('#subscribe').checked) {
        const sources = await SKT.addSource(url.href);
        const src = sources.find((s) => s.url === url.href);
        if (src?.error) throw new Error(src.error);
        state = await UI.loadState();
        const prefix = SKT.sourcePrefix(url.href);
        const themes = Object.values(state.sourceThemes).filter((t) => t.id.startsWith(prefix));
        showImported(themes);
        renderSources();
        reportImport(themes);
      } else {
        const { themes, errors } = await SKT.loadFromUrl(url.href);
        const added = await addUserThemes(themes);
        showImported(added);
        reportImport(added, errors);
      }
      renderList();
    } catch (e) {
      toast(`Import fehlgeschlagen: ${e.message}`, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Laden';
    }
  });

  async function importText(text) {
    try {
      const { themes, errors } = SKT.parseThemePayload(text, { trusted: false });
      const added = await addUserThemes(themes);
      showImported(added);
      reportImport(added, errors);
      renderList();
    } catch (e) {
      toast(`Import fehlgeschlagen: ${e.message}`, 'error');
    }
  }

  $('#importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 2_000_000) return toast('Datei ist zu groß', 'error');
    importText(await file.text());
  });
  $('#importJsonBtn').addEventListener('click', () => {
    const text = $('#importJson').value.trim();
    if (!text) return toast('Bitte JSON einfügen', 'error');
    importText(text).then(() => ($('#importJson').value = ''));
  });

  function timeAgo(ts) {
    if (!ts) return 'nie';
    const min = Math.round((Date.now() - ts) / 60000);
    if (min < 1) return 'gerade eben';
    if (min < 60) return `vor ${min} Min.`;
    const h = Math.round(min / 60);
    return h < 48 ? `vor ${h} Std.` : `vor ${Math.round(h / 24)} Tagen`;
  }

  function renderSources() {
    const root = $('#sourceList');
    root.textContent = '';
    for (const src of state.sources) {
      root.append(
        el('div', { class: 'source' },
          el('div', { class: 'src-main' },
            el('div', { class: 'src-name', text: src.name || src.url }),
            el('div', { class: 'src-url', text: src.url, title: src.url }),
            el('div', {
              class: `src-meta${src.error ? ' error' : ''}`,
              text: src.error ? `Fehler: ${src.error} (${timeAgo(src.lastFetched)})` : `${src.count || 0} Themes · aktualisiert ${timeAgo(src.lastFetched)}`,
            })),
          el('button', { class: 'btn small', text: 'Aktualisieren', onclick: async (e) => {
            e.target.disabled = true;
            await SKT.refreshSources(src.url);
            state = await UI.loadState();
            renderSources();
            renderList();
            toast('Quelle aktualisiert');
          } }),
          el('button', { class: 'btn small danger', text: 'Entfernen', onclick: async () => {
            if (!confirm(`Quelle „${src.name || src.url}“ und ihre Themes entfernen?`)) return;
            await SKT.removeSource(src.url);
            state = await UI.loadState();
            renderSources();
            renderList();
          } }))
      );
    }
    $('#refreshAll').disabled = !state.sources.length;
  }

  $('#refreshAll').addEventListener('click', async (e) => {
    e.target.disabled = true;
    await SKT.refreshSources();
    state = await UI.loadState();
    renderSources();
    renderList();
    toast('Quellen aktualisiert');
  });

  $('#formatExample').textContent = JSON.stringify(
    {
      name: 'Meine Theme-Sammlung',
      themes: [
        {
          id: 'ocean',
          name: 'Ocean',
          author: 'du',
          colors: {
            primary: '#0e7490', accent: '#2563eb', background: '#071318', surface: '#0b1c23', border: '#16313b',
            text: '#ecfeff', muted: '#8fb5c0', secondary: '#cfe6ec', success: '#22c55e', danger: '#ef4444', warning: '#f59e0b', info: '#06b6d4',
          },
          font: 'Inter',
          tintImages: true,
          css: '.navbar { backdrop-filter: blur(8px); }',
        },
      ],
    },
    null,
    2
  );

  // ----------------------------------------------------------- Einstellungen

  async function updateCacheInfo() {
    const all = await api.storage.local.get(null);
    const keys = Object.keys(all).filter((k) => /^css\d+:/.test(k));
    const bytes = keys.reduce((sum, k) => sum + (all[k]?.css?.length || 0), 0);
    $('#cacheInfo').textContent = `${keys.length} Stylesheets · ${(bytes / 1024).toFixed(0)} KB`;
  }

  $('#clearCache').addEventListener('click', async () => {
    const all = await api.storage.local.get(null);
    await api.storage.local.remove(Object.keys(all).filter((k) => /^css\d+:/.test(k)));
    updateCacheInfo();
    toast('Cache geleert – skrime.eu-Tabs bitte neu laden');
  });

  // ------------------------------------------------------ Dashboard-Gruppen

  async function loadDashboardLayout() {
    return (await api.storage.local.get('dashboardLayout')).dashboardLayout || null;
  }

  async function renderDashboardSettings() {
    const layout = await loadDashboardLayout();
    $('#dashEnabled').checked = layout?.prefs?.enabled !== false;
    const groups = layout?.groups?.length || 0;
    const custom = Object.keys(layout?.meta || {}).length;
    $('#dashInfo').textContent = layout ? `${groups} Gruppen · ${custom} angepasste Produkte` : 'Noch kein Layout – wird beim ersten Besuch des Dashboards angelegt.';
    $('#dashExport').disabled = !layout;
  }

  $('#dashEnabled').addEventListener('change', async (e) => {
    const layout = (await loadDashboardLayout()) || {};
    layout.prefs = { ...(layout.prefs || {}), enabled: e.target.checked };
    layout.rev = `options-${Date.now().toString(36)}`;
    await api.storage.local.set({ dashboardLayout: layout });
    toast(e.target.checked ? 'Gruppenansicht aktiviert' : 'Gruppenansicht deaktiviert');
  });

  $('#dashExport').addEventListener('click', async () => {
    const layout = await loadDashboardLayout();
    if (!layout) return;
    const { rev, ...rest } = layout;
    download('skrime-dashboard-layout.json', { skrimeDashboardLayout: 1, ...rest });
  });

  $('#dashReset').addEventListener('click', async () => {
    if (!confirm('Alle Gruppen, eigenen Namen, Tags und Notizen im Dashboard löschen?')) return;
    await api.storage.local.remove('dashboardLayout');
    renderDashboardSettings();
    toast('Dashboard-Layout zurückgesetzt');
  });

  $('#backup').addEventListener('click', () => {
    const themes = Object.values(state.userThemes).map(SKT.exportTheme);
    if (!themes.length) return toast('Keine eigenen Themes vorhanden', 'error');
    download('skrime-themes-backup.json', { name: 'Skrime Themes Backup', themes });
  });

  $('#reset').addEventListener('click', async () => {
    if (!confirm('Alle eigenen Themes, Quellen und Einstellungen löschen?')) return;
    await api.storage.local.clear();
    await api.storage.local.set({ settings: { ...SKT.DEFAULT_SETTINGS } });
    location.hash = '';
    location.reload();
  });

  // ------------------------------------------------------------ Sync & Start

  api.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'local' || !(changes.settings || changes.userThemes || changes.sourceThemes || changes.sources)) return;
    state = await UI.loadState();
    $('#enabled').checked = state.settings.enabled;
    $('#livePreview').checked = state.settings.livePreview;
    renderSources();
    if (current) changed();
  });

  const datalist = $('#fontList');
  for (const f of FONTS) datalist.append(el('option', { value: f }));
  buildColorFields();
  $('#enabled').checked = state.settings.enabled;
  $('#livePreview').checked = state.settings.livePreview;
  renderSources();

  const hash = decodeURIComponent(location.hash.slice(1));
  const editId = hash.startsWith('edit=') ? hash.slice(5) : null;
  select(editId && findTheme(editId) ? editId : SKT.resolveTheme(state).id, { force: true });
  if (hash === 'import') showTab('import');
})();
