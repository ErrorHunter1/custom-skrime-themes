/* Gemeinsame Helfer für Popup und Editor */
(function (root) {
  'use strict';
  const SKT = root.SKT;
  const api = root.browser ?? root.chrome;

  const UI = (root.UI = {});

  UI.api = api;

  UI.el = function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) if (c != null) node.append(c);
    return node;
  };

  /** Setzt --t-* Variablen für Miniaturen/Vorschau. */
  UI.applyThemeVars = function (node, colors) {
    for (const role of SKT.ROLES) node.style.setProperty(`--t-${role}`, colors[role] || SKT.ORIGINAL_COLORS[role]);
  };

  UI.mini = function (theme) {
    const m = UI.el('div', { class: 'mini', 'aria-hidden': 'true' }, UI.el('div', { class: 'hero' }), UI.el('div', { class: 'card' }));
    UI.applyThemeVars(m, theme.colors);
    return m;
  };

  UI.loadState = async function () {
    const s = await api.storage.local.get(['settings', 'userThemes', 'sourceThemes', 'sources', 'approvedCss']);
    s.settings = { ...SKT.DEFAULT_SETTINGS, ...(s.settings || {}) };
    s.userThemes = s.userThemes || {};
    s.sourceThemes = s.sourceThemes || {};
    s.sources = s.sources || [];
    s.approvedCss = s.approvedCss || {};
    return s;
  };

  UI.saveSettings = function (settings) {
    return api.storage.local.set({ settings });
  };

  UI.kindLabel = function (theme) {
    if (theme.kind === 'preset') return 'Vorlage';
    if (theme.kind === 'source') return 'Quelle';
    return 'Eigenes';
  };

  let toastTimer;
  UI.toast = function (msg, type = '') {
    let t = document.querySelector('.toast');
    if (!t) {
      t = UI.el('div', { class: 'toast', role: 'status' });
      document.body.append(t);
    }
    t.textContent = msg;
    t.className = `toast show ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), type === 'error' ? 4500 : 2200);
  };
})(globalThis);
