/*
 * Hintergrund: Standardwerte setzen, den Stylesheet-Cache klein halten und
 * abonnierte Theme-Quellen regelmäßig aktualisieren.
 */
if (typeof importScripts === 'function' && !globalThis.SKT?.refreshSources) {
  // Chrome (Service Worker). Firefox lädt die Skripte über background.scripts.
  importScripts('color.js', 'rewriter.js', 'themes.js', 'sources.js');
}

const api = globalThis.browser ?? globalThis.chrome;
const SKT = globalThis.SKT;
const REFRESH_ALARM = 'skt-refresh-sources';
// 8 Stylesheets pro skrime-Version -> Platz für die aktuelle und zwei ältere Versionen.
const MAX_CACHE_ENTRIES = 24;

/**
 * Entfernt Cache-Einträge älterer Rewriter-Versionen und behält von den
 * aktuellen nur die neuesten. Neue skrime-Versionen haben eine neue ?v=-URL
 * und damit einen neuen Schlüssel, alte Einträge werden so nach und nach verdrängt.
 */
async function pruneCache() {
  const all = await api.storage.local.get(null);
  const current = `css${SKT.REWRITER_VERSION}:`;
  const keys = Object.keys(all).filter((k) => /^css\d+:/.test(k));
  const stale = keys.filter((k) => !k.startsWith(current));
  const fresh = keys.filter((k) => k.startsWith(current)).sort((a, b) => (all[b]?.t || 0) - (all[a]?.t || 0));
  const drop = [...stale, ...fresh.slice(MAX_CACHE_ENTRIES)];
  if (drop.length) await api.storage.local.remove(drop);
}

async function ensureAlarm() {
  const existing = await api.alarms.get(REFRESH_ALARM);
  if (!existing) api.alarms.create(REFRESH_ALARM, { periodInMinutes: 360, delayInMinutes: 1 });
}

api.runtime.onInstalled.addListener(async () => {
  const { settings } = await api.storage.local.get('settings');
  if (!settings) await api.storage.local.set({ settings: { ...SKT.DEFAULT_SETTINGS } });
  await pruneCache();
  await ensureAlarm();
});

api.runtime.onStartup?.addListener(async () => {
  await pruneCache();
  await ensureAlarm();
});

api.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== REFRESH_ALARM) return;
  try {
    await pruneCache();
    await SKT.refreshSources();
  } catch (e) {
    console.warn('[Skrime Themes]', e);
  }
});
