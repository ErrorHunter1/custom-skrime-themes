/*
 * Gruppenansicht für das skrime-Dashboard (https://skrime.eu/dashboard).
 *
 * - Produkte kommen aus der skrime-API (/api/product/all) mit der Login-Session
 *   des Nutzers. Es wird kein API-Key benötigt.
 * - Live-Status und Tarifname werden aus den (ausgeblendeten) Original-Karten
 *   gelesen, die skrime selbst alle 5 Sekunden aktualisiert.
 * - Gruppen, Reihenfolge, eigene Namen, Tags und Notizen liegen lokal in
 *   storage.local ("dashboardLayout"). Produktdaten werden nicht gespeichert,
 *   Zugangsdaten aus der API (Passwörter etc.) werden sofort verworfen.
 */
(() => {
  'use strict';
  const SKT = globalThis.SKT;
  if (!SKT || globalThis.__sktDashboardLoaded) return;
  if (!/^\/dashboard\/?$/.test(location.pathname)) return;
  globalThis.__sktDashboardLoaded = true;

  const api = globalThis.browser ?? globalThis.chrome;
  const doc = document;
  const STORAGE_KEY = 'dashboardLayout';
  const REFRESH_MS = 60_000;
  const UNSORTED = '__unsorted';
  const ID_RE = /^[\w-]{1,64}$/;
  const HEX_RE = /^#[0-9a-f]{6}$/i;

  // Firefox: content.fetch läuft im Kontext der Seite (mit Session-Cookies).
  // eslint-disable-next-line no-undef
  const pageFetch = typeof content !== 'undefined' && typeof content?.fetch === 'function' ? content.fetch.bind(content) : globalThis.fetch.bind(globalThis);

  // Originalfarben, die die Ansicht nutzt – werden bei der Theme-Engine angemeldet.
  const PANEL_COLORS = ['2f55d4', '0f1014', '15171c', '2a2d35', '252930', 'f8f9fa', 'adb5bd', '2eca8b', 'e43f52', 'f17425', '17a2b8'];

  const CATEGORIES = [
    { id: 'server', name: 'Server', icon: 'fa-server' },
    { id: 'teamspeak', name: 'TeamSpeak', icon: 'fa-microphone-lines' },
    { id: 'web', name: 'Web & Domains', icon: 'fa-earth-europe' },
    { id: 'service', name: 'Service', icon: 'fa-gear' },
  ];

  const TYPES = {
    server: { label: 'KVM Server', icon: 'fa-server', cat: 'server' },
    dedicated: { label: 'Dedicated Server', icon: 'fa-microchip', cat: 'server' },
    gameserver: { label: 'Gameserver', icon: 'fa-gamepad', cat: 'server' },
    instance: { label: 'TeamSpeak Instanz', icon: 'fa-microphone-lines', cat: 'teamspeak' },
    teamspeak: { label: 'TeamSpeak Server', icon: 'fa-microphone-lines', cat: 'teamspeak' },
    domain: { label: 'Domain', icon: 'fa-earth-europe', cat: 'web' },
    dns: { label: 'DNS Zone', icon: 'fa-sitemap', cat: 'web' },
    ssl: { label: 'SSL Zertifikat', icon: 'fa-lock-keyhole', cat: 'web' },
    webspace: { label: 'Webspace', icon: 'fa-browser', cat: 'web' },
    mail: { label: 'Mail Service', icon: 'fa-mailbox-open-letter', cat: 'web' },
    ipv4: { label: 'IPv4 Netz', icon: 'fa-circle-nodes', cat: 'service' },
    ipv6: { label: 'IPv6 Netz', icon: 'fa-circle-nodes', cat: 'service' },
    asn: { label: 'ASN', icon: 'fa-network-wired', cat: 'service' },
    'proxmox-backup': { label: 'Proxmox Backup', icon: 'fa-box-archive', cat: 'service' },
    status: { label: 'Statusseite', icon: 'fa-chart-line-up', cat: 'service' },
  };

  const SWATCHES = ['#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#ec4899', '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6', '#06b6d4', '#94a3b8'];
  const GROUP_ICONS = [
    'fa-folder', 'fa-server', 'fa-earth-europe', 'fa-gamepad', 'fa-briefcase', 'fa-house', 'fa-flask', 'fa-users',
    'fa-shield-halved', 'fa-rocket', 'fa-database', 'fa-code', 'fa-star', 'fa-heart', 'fa-cloud', 'fa-microphone-lines',
    'fa-gear', 'fa-box-archive', 'fa-network-wired', 'fa-envelope', 'fa-cart-shopping', 'fa-graduation-cap', 'fa-robot', 'fa-fire',
  ];
  const VIEWS = [
    { id: 'list', label: 'Liste', icon: 'fa-list' },
    { id: 'compact', label: 'Kompakt', icon: 'fa-bars' },
    { id: 'cards', label: 'Kacheln', icon: 'fa-grid-2' },
  ];
  const SORTS = [
    { id: 'manual', label: 'Manuell sortiert' },
    { id: 'name', label: 'Name' },
    { id: 'expiry', label: 'Ablaufdatum' },
    { id: 'price', label: 'Preis' },
    { id: 'status', label: 'Status' },
    { id: 'type', label: 'Typ' },
  ];
  const COLUMNS = [
    { id: 'specs', label: 'Spezifikationen' },
    { id: 'meta', label: 'Tags & Notizen' },
    { id: 'expiry', label: 'Ablaufdatum' },
    { id: 'price', label: 'Preis' },
  ];
  const DEFAULT_PREFS = {
    enabled: true,
    view: 'list',
    sort: 'manual',
    filter: 'all',
    showDeleted: false,
    showHidden: false,
    columns: { specs: true, meta: true, expiry: true, price: true },
  };

  const eur = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });
  const dateFmt = new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });

  // ---------------------------------------------------------------- Zustand

  let products = [];
  let byId = new Map();
  let productsLoaded = false;
  let loadError = null;
  let statusMap = new Map();
  let layout = normalizeLayout(null);
  let lastWrittenRev = null;
  let saveTimer = null;
  let renderPending = false;
  const ui = { search: '', drag: null, drop: null, editing: false };

  let rootEl, groupsEl, subEl, chipsEl, segEl, sortEl, restoreEl, originals = [];
  const prefs = () => layout.prefs;

  // --------------------------------------------------------------- Helfer

  function h(tag, attrs = {}, ...children) {
    const node = doc.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : String(v));
    }
    for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) node.append(c);
    return node;
  }
  const icon = (name, style = 'fa-duotone') => h('i', { class: `${style} ${name}`, 'aria-hidden': 'true' });
  const uid = () => Math.random().toString(36).slice(2, 10);
  const typeInfo = (type) => TYPES[type] || { label: type || 'Produkt', icon: 'fa-box', cat: 'service' };
  const catOf = (p) => typeInfo(p.type).cat;
  const monthly = (p) => (p.state === 'active' ? p.price / p.duration : 0);

  function debounce(fn, ms) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  }

  function parseDate(s) {
    if (!s) return null;
    const d = new Date(String(s).replace(' ', 'T'));
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function daysLeft(p) {
    const d = parseDate(p.expireAt);
    return d ? Math.ceil((d.getTime() - Date.now()) / 86_400_000) : null;
  }

  function relDays(days) {
    if (days === null) return '';
    if (days < 0) return `seit ${-days} ${-days === 1 ? 'Tag' : 'Tagen'} abgelaufen`;
    if (days === 0) return 'läuft heute ab';
    if (days === 1) return 'morgen';
    return `in ${days} Tagen`;
  }

  function periodLabel(duration) {
    return { 1: 'pro Monat', 3: 'pro Quartal', 6: 'pro Halbjahr', 12: 'pro Jahr' }[duration] || `alle ${duration} Monate`;
  }

  function formatMemory(mb) {
    if (!mb) return '';
    return mb >= 1024 ? `${Math.round((mb / 1024) * 10) / 10} GB` : `${mb} MB`;
  }

  // ------------------------------------------------------------ API-Daten

  async function skrimeApi(path, body = {}) {
    const res = await pageFetch(`${location.origin}/api/${path}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'Method-Override': 'GET' },
      body: JSON.stringify(body),
    });
    let json = null;
    try {
      json = await res.json();
    } catch {
      /* keine JSON-Antwort */
    }
    if (!res.ok || json?.state !== 'success') {
      throw new Error(res.status === 401 ? 'Nicht eingeloggt' : json?.response || `HTTP ${res.status}`);
    }
    return json.data;
  }

  /** Übernimmt nur unkritische Felder – Passwörter, Benutzernamen etc. werden verworfen. */
  function sanitizeProduct(p) {
    const info = p?.productInfo && typeof p.productInfo === 'object' ? p.productInfo : {};
    const num = (v) => (v === undefined || v === null || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
    const rights = p?.userRights && typeof p.userRights === 'object' && !Array.isArray(p.userRights) ? Object.values(p.userRights) : [];
    const isServer = ['server', 'dedicated', 'gameserver'].includes(p?.type);
    return {
      id: String(p.id),
      type: String(p.type || ''),
      state: String(p.state || ''),
      customName: String(p.customName || '').slice(0, 120),
      price: Number(p.price) || 0,
      duration: Math.max(1, Number(p.duration) || 1),
      expireAt: p.expireAt || null,
      createdAt: p.createdAt || null,
      autoRenew: !!p.autoRenew,
      cores: isServer ? num(info.cores) : null,
      memory: isServer ? num(info.memory) : null,
      disk: isServer ? num(info.disk) : null,
      cpuType: isServer && typeof info.type === 'string' ? info.type.slice(0, 20) : '',
      ident: String(info.domain || info.zone || info.prefix || info.asName || '').slice(0, 120),
      slots: info.slots ? String(info.slots).slice(0, 10) : '',
      shared: rights.map((r) => String(r).slice(0, 40)).slice(0, 10),
    };
  }

  let productsSignature = '';

  async function loadProducts() {
    try {
      const data = await skrimeApi('product/all');
      const next = (Array.isArray(data) ? data : []).filter((p) => p && ID_RE.test(String(p.id))).map(sanitizeProduct);
      const signature = JSON.stringify(next);
      if (productsLoaded && !loadError && signature === productsSignature) return;
      productsSignature = signature;
      products = next;
      byId = new Map(products.map((p) => [p.id, p]));
      productsLoaded = true;
      loadError = null;
      if (reconcile()) save();
    } catch (err) {
      loadError = err.message || String(err);
    }
    render();
  }

  /** Liest Status und Tarifname aus skrimes eigenen (ausgeblendeten) Karten. */
  function readStatuses() {
    const map = new Map();
    for (const a of doc.querySelectorAll('#pills-tabContent a[href*="/manage/"]')) {
      const m = /\/manage\/([\w-]{8,64})\//.exec(a.getAttribute('href') || '');
      if (!m) continue;
      const box = a.closest('.col-md-6, .col-md-12, tr');
      if (!box) continue;
      const dot = box.querySelector('i.fa-circle');
      let status = null;
      if (dot) {
        if (dot.classList.contains('text-success')) status = 'online';
        else if (dot.classList.contains('text-danger')) status = 'offline';
        else if (dot.classList.contains('text-warning')) status = 'warning';
      }
      const title = dot?.getAttribute('data-bs-original-title') || dot?.getAttribute('title') || '';
      const plan = box.querySelector('p.small')?.textContent.trim().slice(0, 80) || '';
      map.set(m[1], { status, title: title.slice(0, 60), plan });
    }
    return map;
  }

  function onSkrimeUpdate() {
    const next = readStatuses();
    const same = next.size === statusMap.size && [...next].every(([id, v]) => JSON.stringify(v) === JSON.stringify(statusMap.get(id)));
    if (same) return;
    statusMap = next;
    render();
  }

  // ---------------------------------------------------------------- Layout

  function cleanMeta(m) {
    const out = {};
    if (!m || typeof m !== 'object') return out;
    if (m.alias) out.alias = String(m.alias).trim().slice(0, 80);
    if (m.note) out.note = String(m.note).slice(0, 1000);
    if (Array.isArray(m.tags)) {
      const tags = [...new Set(m.tags.map((t) => String(t).trim().slice(0, 24)).filter(Boolean))].slice(0, 12);
      if (tags.length) out.tags = tags;
    }
    if (HEX_RE.test(m.color)) out.color = m.color.toLowerCase();
    if (m.hidden) out.hidden = true;
    return out;
  }

  function normalizeLayout(raw) {
    const l = {
      version: 1,
      rev: null,
      initialized: false,
      groups: [],
      unsorted: [],
      meta: {},
      prefs: { ...DEFAULT_PREFS, columns: { ...DEFAULT_PREFS.columns } },
    };
    if (!raw || typeof raw !== 'object') return l;
    l.rev = typeof raw.rev === 'string' ? raw.rev : null;
    l.initialized = !!raw.initialized;

    const seenItems = new Set();
    const ids = (arr) =>
      (Array.isArray(arr) ? arr : [])
        .map(String)
        .filter((id) => ID_RE.test(id) && !seenItems.has(id) && seenItems.add(id));
    const seenGroups = new Set();
    for (const g of Array.isArray(raw.groups) ? raw.groups.slice(0, 100) : []) {
      if (!g || typeof g !== 'object') continue;
      let id = String(g.id || '').replace(/[^\w-]/g, '').slice(0, 40);
      if (!id || id === UNSORTED || seenGroups.has(id)) id = uid();
      seenGroups.add(id);
      l.groups.push({
        id,
        name: String(g.name || 'Gruppe').trim().slice(0, 60) || 'Gruppe',
        color: HEX_RE.test(g.color) ? g.color.toLowerCase() : null,
        icon: GROUP_ICONS.includes(g.icon) ? g.icon : 'fa-folder',
        collapsed: !!g.collapsed,
        auto: CATEGORIES.some((c) => c.id === g.auto) ? g.auto : null,
        items: ids(g.items),
      });
    }
    l.unsorted = ids(raw.unsorted);
    if (raw.meta && typeof raw.meta === 'object') {
      for (const [id, m] of Object.entries(raw.meta)) {
        if (!ID_RE.test(id)) continue;
        const clean = cleanMeta(m);
        if (Object.keys(clean).length) l.meta[id] = clean;
      }
    }
    const p = raw.prefs && typeof raw.prefs === 'object' ? raw.prefs : {};
    if (typeof p.enabled === 'boolean') l.prefs.enabled = p.enabled;
    if (VIEWS.some((v) => v.id === p.view)) l.prefs.view = p.view;
    if (SORTS.some((s) => s.id === p.sort)) l.prefs.sort = p.sort;
    if (p.filter === 'all' || CATEGORIES.some((c) => c.id === p.filter)) l.prefs.filter = p.filter;
    l.prefs.showDeleted = !!p.showDeleted;
    l.prefs.showHidden = !!p.showHidden;
    if (p.columns && typeof p.columns === 'object') {
      for (const c of COLUMNS) if (typeof p.columns[c.id] === 'boolean') l.prefs.columns[c.id] = p.columns[c.id];
    }
    return l;
  }

  function defaultOrder(a, b) {
    const active = (p) => (p.state === 'active' ? 0 : 1);
    const cat = (p) => CATEGORIES.findIndex((c) => c.id === catOf(p));
    return active(a) - active(b) || cat(a) - cat(b) || a.type.localeCompare(b.type) || displayName(a).localeCompare(displayName(b), 'de');
  }

  /**
   * Gleicht das Layout mit der Produktliste ab: neue Produkte einsortieren,
   * verschwundene entfernen. Gibt true zurück, wenn sich etwas geändert hat.
   */
  function reconcile() {
    if (!productsLoaded) return false;
    let changed = false;
    const keep = (list) => {
      const next = list.filter((id) => byId.has(id));
      if (next.length !== list.length) changed = true;
      return next;
    };
    for (const g of layout.groups) g.items = keep(g.items);
    layout.unsorted = keep(layout.unsorted);
    for (const id of Object.keys(layout.meta)) {
      if (!byId.has(id)) {
        delete layout.meta[id];
        changed = true;
      }
    }

    const placed = new Set([...layout.groups.flatMap((g) => g.items), ...layout.unsorted]);
    const fresh = products.filter((p) => !placed.has(p.id)).sort(defaultOrder);
    if (!fresh.length) return changed;

    if (!layout.initialized && !layout.groups.length) {
      for (const cat of CATEGORIES) {
        if (fresh.some((p) => catOf(p) === cat.id && p.state !== 'deleted')) {
          layout.groups.push({ id: uid(), name: cat.name, color: null, icon: cat.icon, collapsed: false, auto: cat.id, items: [] });
        }
      }
    }
    for (const p of fresh) {
      const target = layout.groups.find((g) => g.auto === catOf(p));
      (target ? target.items : layout.unsorted).push(p.id);
    }
    layout.initialized = true;
    return true;
  }

  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      layout.rev = `${Date.now().toString(36)}-${uid()}`;
      lastWrittenRev = layout.rev;
      try {
        await api.storage.local.set({ [STORAGE_KEY]: layout });
      } catch (err) {
        console.warn('[Skrime Themes] Layout nicht gespeichert:', err);
      }
    }, 120);
  }

  function update(fn) {
    fn(layout);
    save();
    render();
  }

  const findGroup = (gid) => layout.groups.find((g) => g.id === gid);
  const listOf = (gid) => (gid === UNSORTED ? layout.unsorted : findGroup(gid)?.items);
  const groupOfItem = (id) => (layout.unsorted.includes(id) ? UNSORTED : layout.groups.find((g) => g.items.includes(id))?.id);

  function moveItem(id, gid, beforeId = null) {
    const target = listOf(gid);
    if (!target) return;
    update(() => {
      for (const g of layout.groups) g.items = g.items.filter((x) => x !== id);
      layout.unsorted = layout.unsorted.filter((x) => x !== id);
      const list = listOf(gid);
      const idx = beforeId ? list.indexOf(beforeId) : -1;
      if (idx < 0) list.push(id);
      else list.splice(idx, 0, id);
    });
  }

  function moveGroup(gid, beforeGid) {
    if (gid === beforeGid) return;
    update(() => {
      const idx = layout.groups.findIndex((g) => g.id === gid);
      if (idx < 0) return;
      const [g] = layout.groups.splice(idx, 1);
      const to = beforeGid ? layout.groups.findIndex((x) => x.id === beforeGid) : -1;
      if (to < 0) layout.groups.push(g);
      else layout.groups.splice(to, 0, g);
    });
  }

  function deleteGroup(gid) {
    const g = findGroup(gid);
    if (!g) return;
    const msg = g.items.length
      ? `Gruppe „${g.name}“ löschen? Die ${g.items.length} Produkte landen unter „Nicht zugeordnet“.`
      : `Gruppe „${g.name}“ löschen?`;
    if (!confirm(msg)) return;
    update((l) => {
      l.unsorted.push(...g.items);
      l.groups = l.groups.filter((x) => x.id !== gid);
    });
  }

  function setMeta(id, patch) {
    update((l) => {
      const next = cleanMeta({ ...(l.meta[id] || {}), ...patch });
      if (Object.keys(next).length) l.meta[id] = next;
      else delete l.meta[id];
    });
  }

  // ---------------------------------------------------------- Darstellung

  // skrime vergibt als Standardnamen oft nur den Typ ("Domain", "DNS Zone") –
  // dann ist der Domain-/Zonenname aussagekräftiger.
  const GENERIC_NAMES = new Set(Object.values(TYPES).map((t) => t.label.toLowerCase()).concat(['domain', 'dns zone', 'dns', 'ssl', 'webspace']));

  function baseName(p) {
    if (p.ident && (!p.customName || GENERIC_NAMES.has(p.customName.toLowerCase()))) return p.ident;
    return p.customName || p.ident || `${typeInfo(p.type).label} ${p.id.slice(0, 8)}`;
  }

  function displayName(p) {
    return layout.meta[p.id]?.alias || baseName(p);
  }

  function subline(p) {
    const parts = [];
    const live = statusMap.get(p.id);
    parts.push(live?.plan || `${typeInfo(p.type).label}${p.cpuType ? ` (${p.cpuType.toUpperCase()})` : ''}`);
    if (prefs().columns.specs) {
      if (p.cores) parts.push(`${p.cores} vCores`);
      if (p.memory) parts.push(`${formatMemory(p.memory)} RAM`);
      if (p.disk) parts.push(`${p.disk} GB Disk`);
      if (p.slots) parts.push(`${p.slots} Slots`);
    }
    if (p.ident && displayName(p) !== p.ident) parts.push(p.ident);
    return parts.join(' · ');
  }

  function statusOf(p) {
    const live = statusMap.get(p.id);
    if (p.state === 'deleted') return { cls: '', title: 'Gelöscht' };
    if (['install', 'reinstall', 'upgrade', 'processing', 'pending'].includes(p.state)) return { cls: 'is-warning', title: p.state };
    if (p.state !== 'active') return { cls: 'is-offline', title: p.state };
    if (live?.status === 'online') return { cls: 'is-online', title: live.title || 'Online' };
    if (live?.status === 'offline') return { cls: 'is-offline', title: live.title || 'Offline' };
    if (live?.status === 'warning') return { cls: 'is-warning', title: live.title || 'Warnung' };
    return { cls: '', title: 'Aktiv' };
  }

  const STATUS_RANK = { 'is-offline': 0, 'is-warning': 1, '': 2, 'is-online': 3 };
  const COMPARATORS = {
    name: (a, b) => displayName(a).localeCompare(displayName(b), 'de', { numeric: true }),
    expiry: (a, b) => (parseDate(a.expireAt)?.getTime() ?? Infinity) - (parseDate(b.expireAt)?.getTime() ?? Infinity),
    price: (a, b) => b.price / b.duration - a.price / a.duration,
    status: (a, b) => STATUS_RANK[statusOf(a).cls] - STATUS_RANK[statusOf(b).cls] || COMPARATORS.name(a, b),
    type: (a, b) => a.type.localeCompare(b.type) || COMPARATORS.name(a, b),
  };

  function searchText(p) {
    const m = layout.meta[p.id] || {};
    return [displayName(p), p.customName, p.ident, typeInfo(p.type).label, statusMap.get(p.id)?.plan, m.note, ...(m.tags || []).map((t) => `#${t} ${t}`)]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
  }

  function visibleItems(ids) {
    const q = ui.search.trim().toLowerCase();
    const terms = q ? q.split(/\s+/) : [];
    let list = ids.map((id) => byId.get(id)).filter((p) => {
      if (!p) return false;
      const m = layout.meta[p.id] || {};
      if (p.state === 'deleted' && !prefs().showDeleted) return false;
      if (m.hidden && !prefs().showHidden) return false;
      if (prefs().filter !== 'all' && catOf(p) !== prefs().filter) return false;
      if (terms.length) {
        // Produkt-IDs (UUIDs) erst ab 6 Zeichen durchsuchen, sonst trifft fast alles.
        const idMatch = q.length >= 6 && p.id.toLowerCase().includes(q);
        const text = searchText(p);
        if (!idMatch && !terms.every((t) => text.includes(t))) return false;
      }
      return true;
    });
    if (prefs().sort !== 'manual') list = [...list].sort(COMPARATORS[prefs().sort]);
    return list;
  }

  function gridColumns() {
    const c = prefs().columns;
    const iconCol = prefs().view === 'compact' ? '22px' : '34px';
    const full = ['14px', iconCol, 'minmax(180px, 1.6fr)'];
    if (c.meta) full.push('minmax(0, 1fr)');
    const compact = prefs().view === 'compact';
    const tail = [];
    if (c.expiry) tail.push(compact ? '180px' : '118px');
    if (c.price) tail.push(compact ? '150px' : '112px');
    tail.push('auto');
    return {
      lg: [...full, ...tail].join(' '),
      md: ['14px', iconCol, 'minmax(0, 1fr)', ...tail].join(' '),
      sm: ['14px', iconCol, 'minmax(0, 1fr)', 'auto'].join(' '),
    };
  }

  function render() {
    if (!rootEl) return;
    if (ui.drag || ui.editing) {
      renderPending = true;
      return;
    }
    renderPending = false;
    applyEnabled();
    const cols = gridColumns();
    rootEl.dataset.view = prefs().view;
    rootEl.style.setProperty('--skp-cols', cols.lg);
    rootEl.style.setProperty('--skp-cols-md', cols.md);
    rootEl.style.setProperty('--skp-cols-sm', cols.sm);
    renderToolbar();
    renderGroups();
  }

  function renderToolbar() {
    const active = products.filter((p) => p.state === 'active');
    const total = active.reduce((sum, p) => sum + monthly(p), 0);
    subEl.textContent = productsLoaded ? `${active.length} aktive Produkte · ${eur.format(total)} pro Monat` : 'Lädt…';

    chipsEl.replaceChildren(
      ...[{ id: 'all', name: 'Alle' }, ...CATEGORIES].flatMap((c) => {
        const count = c.id === 'all' ? active.length : active.filter((p) => catOf(p) === c.id).length;
        if (c.id !== 'all' && !count) return [];
        return h(
          'button',
          {
            type: 'button',
            class: `skp-chip${prefs().filter === c.id ? ' is-active' : ''}`,
            onclick: () => update((l) => (l.prefs.filter = c.id)),
          },
          c.name,
          h('b', { text: String(count) })
        );
      })
    );
    for (const b of segEl.children) b.classList.toggle('is-active', b.dataset.view === prefs().view);
    sortEl.value = prefs().sort;
  }

  function unsortedGroup() {
    return { id: UNSORTED, name: 'Nicht zugeordnet', color: '#94a3b8', icon: 'fa-inbox', collapsed: false, items: layout.unsorted };
  }

  function renderGroups() {
    const frag = doc.createDocumentFragment();
    if (!productsLoaded) {
      frag.append(
        loadError
          ? h('div', { class: 'skp-state is-error' }, icon('fa-triangle-exclamation'), `Produkte konnten nicht geladen werden: ${loadError}`,
              h('button', { type: 'button', class: 'skp-btn is-sm', onclick: loadProducts }, 'Erneut versuchen'))
          : h('div', { class: 'skp-state' }, icon('fa-spinner-third fa-spin'), 'Produkte werden geladen…')
      );
    } else {
      const filtering = !!ui.search.trim() || prefs().filter !== 'all';
      for (const g of layout.groups) {
        const el = renderGroup(g, filtering);
        if (el) frag.append(el);
      }
      if (visibleItems(layout.unsorted).length) {
        const el = renderGroup(unsortedGroup(), filtering);
        if (el) frag.append(el);
      }
      if (!frag.childNodes.length) {
        frag.append(h('div', { class: 'skp-state' }, filtering ? 'Keine passenden Produkte gefunden.' : 'Noch keine Gruppen – lege mit „Gruppe“ eine an.'));
      }
    }
    groupsEl.replaceChildren(frag);
  }

  function renderGroup(g, filtering) {
    const isUnsorted = g.id === UNSORTED;
    const items = visibleItems(g.items);
    if (filtering && !items.length) return null;
    const collapsed = g.collapsed && !filtering;
    const sum = items.reduce((s, p) => s + monthly(p), 0);

    const name = h('span', { class: 'skp-gname', text: g.name, title: isUnsorted ? null : 'Doppelklick zum Umbenennen' });
    if (!isUnsorted) name.addEventListener('dblclick', () => startRename(g.id, name));

    const head = h(
      'div',
      { class: 'skp-ghead', draggable: isUnsorted ? null : 'true' },
      isUnsorted ? null : h('span', { class: 'skp-grip', title: 'Gruppe verschieben' }, icon('fa-grip-dots-vertical', 'fa-solid')),
      isUnsorted
        ? null
        : h('button', { type: 'button', class: 'skp-btn is-sm is-icon is-ghost skp-collapse', title: collapsed ? 'Ausklappen' : 'Einklappen', 'aria-expanded': String(!collapsed), onclick: () => update(() => (findGroup(g.id).collapsed = !g.collapsed)) },
            icon('fa-chevron-down', 'fa-solid')),
      h('span', { class: 'skp-gicon' }, icon(g.icon)),
      name,
      h('span', { class: 'skp-gcount', text: String(items.length) }),
      h('span', { class: 'skp-gsum', text: sum ? `${eur.format(sum)} / Monat` : '' }),
      isUnsorted
        ? null
        : h('button', { type: 'button', class: 'skp-btn is-sm is-icon is-ghost', title: 'Gruppe bearbeiten', onclick: (e) => openGroupMenu(e.currentTarget, g.id) }, icon('fa-ellipsis', 'fa-solid'))
    );
    if (!isUnsorted) head.addEventListener('click', (e) => {
      if (e.target === head || e.target.classList.contains('skp-gsum')) update(() => (findGroup(g.id).collapsed = !g.collapsed));
    });

    const body = h('div', { class: 'skp-gbody' }, items.length ? items.map(renderItem) : h('div', { class: 'skp-empty', text: 'Ziehe Produkte hierher' }));
    return h('div', { class: `skp-group${collapsed ? ' is-collapsed' : ''}`, 'data-gid': g.id, style: g.color ? `--g:${g.color}` : null }, head, body);
  }

  function renderItem(p) {
    const m = layout.meta[p.id] || {};
    const c = prefs().columns;
    const st = statusOf(p);
    const url = `${location.origin}/${encodeURIComponent(p.type)}/manage/${encodeURIComponent(p.id)}/overview`;
    const days = daysLeft(p);
    const classes = ['skp-item'];
    if (p.state === 'deleted') classes.push('is-deleted', 'is-muted');
    else if (m.hidden) classes.push('is-muted');

    const meta = c.meta
      ? h('div', { class: 'skp-meta' },
          p.state !== 'active' ? h('span', { class: `skp-badge ${p.state === 'deleted' ? 'is-danger' : 'is-warning'}`, text: p.state === 'deleted' ? 'Gelöscht' : p.state }) : null,
          p.shared.length ? h('span', { class: 'skp-badge', title: `Geteilt mit: ${p.shared.join(', ')}` }, icon('fa-users'), 'Geteilt') : null,
          m.hidden ? h('span', { class: 'skp-badge' }, icon('fa-eye-slash'), 'Ausgeblendet') : null,
          (m.tags || []).map((t) => h('span', { class: 'skp-tag', text: t })),
          m.note ? h('div', { class: 'skp-note', title: m.note }, icon('fa-note-sticky'), m.note) : null)
      : null;

    const expiry = c.expiry
      ? h('div', {
          class: `skp-expiry${days !== null && days <= 7 ? ' is-critical' : days !== null && days <= 14 ? ' is-soon' : ''}`,
          title: p.autoRenew ? 'Automatische Verlängerung aktiv' : 'Keine automatische Verlängerung',
        },
        parseDate(p.expireAt) ? dateFmt.format(parseDate(p.expireAt)) : '–',
        h('small', {}, p.autoRenew ? icon('fa-arrows-rotate', 'fa-solid') : null, relDays(days)))
      : null;

    const price = c.price ? h('div', { class: 'skp-price' }, eur.format(p.price), h('small', { text: periodLabel(p.duration) })) : null;

    return h(
      'div',
      { class: classes.join(' '), draggable: 'true', 'data-id': p.id, style: m.color ? `--c:${m.color}` : null },
      h('span', { class: `skp-dot ${st.cls}`, title: st.title }),
      h('span', { class: 'skp-ticon', title: typeInfo(p.type).label }, icon(typeInfo(p.type).icon)),
      h('div', { class: 'skp-main' },
        h('a', { class: 'skp-name', href: url, draggable: 'false', text: displayName(p) }),
        h('div', { class: 'skp-subline', text: subline(p) })),
      meta,
      expiry,
      price,
      h('div', { class: 'skp-actions' },
        h('a', { class: 'skp-btn is-sm is-icon is-ghost', href: url, draggable: 'false', title: 'Verwalten' }, icon('fa-gear', 'fa-solid')),
        h('button', { type: 'button', class: 'skp-btn is-sm is-icon is-ghost', title: 'Anpassen', onclick: () => openItemDialog(p.id) }, icon('fa-pen', 'fa-solid')),
        h('button', { type: 'button', class: 'skp-btn is-sm is-icon is-ghost', title: 'Mehr', onclick: (e) => openItemMenu(e.currentTarget, p.id) }, icon('fa-ellipsis-vertical', 'fa-solid')))
    );
  }

  function startRename(gid, nameEl) {
    const g = findGroup(gid);
    if (!g) return;
    ui.editing = true;
    const head = nameEl.closest('.skp-ghead');
    head.removeAttribute('draggable');
    const input = h('input', { class: 'skp-input skp-gname-input', value: g.name, maxlength: '60', 'aria-label': 'Gruppenname' });
    let done = false;
    const finish = (commit) => {
      if (done) return;
      done = true;
      ui.editing = false;
      const value = input.value.trim();
      if (commit && value && value !== g.name) update(() => (findGroup(gid).name = value.slice(0, 60)));
      else render();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') finish(true);
      if (e.key === 'Escape') finish(false);
    });
    input.addEventListener('blur', () => finish(true));
    nameEl.replaceWith(input);
    input.focus();
    input.select();
  }

  // ------------------------------------------------------------ Menüs

  let openMenu = null;

  function closeMenu() {
    if (!openMenu) return;
    openMenu.el.remove();
    doc.removeEventListener('pointerdown', openMenu.outside, true);
    doc.removeEventListener('keydown', openMenu.key, true);
    window.removeEventListener('scroll', openMenu.close, true);
    openMenu = null;
  }

  function showMenu(anchor, entries) {
    closeMenu();
    const el = h('div', { class: 'skp-menu skp-scope', role: 'menu' });
    for (const e of entries) {
      if (!e) continue;
      if (e === '-') el.append(h('hr'));
      else if (e.heading) el.append(h('div', { class: 'skp-menu-head', text: e.heading }));
      else {
        const checkable = typeof e.checked === 'boolean';
        el.append(
          h('button', {
            type: 'button',
            role: checkable ? 'menuitemcheckbox' : 'menuitem',
            'aria-checked': checkable ? String(e.checked) : null,
            class: [e.danger ? 'is-danger' : '', e.checked ? 'is-checked' : ''].join(' ').trim() || null,
            onclick: () => {
              closeMenu();
              e.action();
            },
          },
          icon(checkable ? (e.checked ? 'fa-square-check' : 'fa-square') : e.icon || 'fa-circle-small', checkable ? 'fa-regular' : 'fa-duotone'),
          h('span', { text: e.label }))
        );
      }
    }
    doc.body.append(el);
    const r = anchor.getBoundingClientRect();
    const mw = el.offsetWidth, mh = el.offsetHeight;
    let left = Math.min(r.right - mw, window.innerWidth - mw - 8);
    let top = r.bottom + 6;
    if (top + mh > window.innerHeight - 8) top = Math.max(8, r.top - mh - 6);
    el.style.left = `${Math.max(8, left)}px`;
    el.style.top = `${top}px`;
    const outside = (ev) => {
      if (!el.contains(ev.target) && ev.target !== anchor && !anchor.contains(ev.target)) closeMenu();
    };
    const key = (ev) => {
      if (ev.key === 'Escape') closeMenu();
    };
    openMenu = { el, outside, key, close: closeMenu };
    doc.addEventListener('pointerdown', outside, true);
    doc.addEventListener('keydown', key, true);
    window.addEventListener('scroll', closeMenu, true);
    el.querySelector('button')?.focus({ preventScroll: true });
  }

  function openMainMenu(anchor) {
    const p = prefs();
    showMenu(anchor, [
      { heading: 'Spalten' },
      ...COLUMNS.map((c) => ({ label: c.label, checked: p.columns[c.id], action: () => update((l) => (l.prefs.columns[c.id] = !p.columns[c.id])) })),
      '-',
      { label: 'Gelöschte Produkte anzeigen', checked: p.showDeleted, action: () => update((l) => (l.prefs.showDeleted = !p.showDeleted)) },
      { label: 'Ausgeblendete anzeigen', checked: p.showHidden, action: () => update((l) => (l.prefs.showHidden = !p.showHidden)) },
      '-',
      { label: 'Alle Gruppen einklappen', icon: 'fa-chevrons-up', action: () => update((l) => l.groups.forEach((g) => (g.collapsed = true))) },
      { label: 'Alle Gruppen ausklappen', icon: 'fa-chevrons-down', action: () => update((l) => l.groups.forEach((g) => (g.collapsed = false))) },
      { label: 'Nach Typ neu gruppieren…', icon: 'fa-wand-magic-sparkles', action: regroupByType },
      '-',
      { label: 'Layout exportieren', icon: 'fa-file-export', action: exportLayout },
      { label: 'Layout importieren…', icon: 'fa-file-import', action: importLayout },
      '-',
      { label: 'Original-Ansicht von skrime', icon: 'fa-rotate-left', action: () => update((l) => (l.prefs.enabled = false)) },
    ]);
  }

  function openGroupMenu(anchor, gid) {
    const g = findGroup(gid);
    if (!g) return;
    const idx = layout.groups.indexOf(g);
    showMenu(anchor, [
      { label: 'Bearbeiten…', icon: 'fa-pen', action: () => openGroupDialog(gid) },
      { label: 'Umbenennen', icon: 'fa-i-cursor', action: () => {
        const nameEl = groupsEl.querySelector(`.skp-group[data-gid="${CSS.escape(gid)}"] .skp-gname`);
        if (nameEl) startRename(gid, nameEl);
      } },
      { label: g.collapsed ? 'Ausklappen' : 'Einklappen', icon: g.collapsed ? 'fa-chevron-down' : 'fa-chevron-up', action: () => update(() => (g.collapsed = !g.collapsed)) },
      idx > 0 ? { label: 'Nach oben', icon: 'fa-arrow-up', action: () => moveGroup(gid, layout.groups[idx - 1].id) } : null,
      idx < layout.groups.length - 1 ? { label: 'Nach unten', icon: 'fa-arrow-down', action: () => moveGroup(gid, layout.groups[idx + 2]?.id || null) } : null,
      '-',
      { label: 'Gruppe löschen', icon: 'fa-trash', danger: true, action: () => deleteGroup(gid) },
    ]);
  }

  function openItemMenu(anchor, id) {
    const p = byId.get(id);
    if (!p) return;
    const m = layout.meta[id] || {};
    const current = groupOfItem(id);
    const url = `${location.origin}/${encodeURIComponent(p.type)}/manage/${encodeURIComponent(p.id)}/overview`;
    showMenu(anchor, [
      { label: 'Anpassen…', icon: 'fa-pen', action: () => openItemDialog(id) },
      { label: 'In neuem Tab öffnen', icon: 'fa-arrow-up-right-from-square', action: () => window.open(url, '_blank', 'noopener') },
      { label: m.hidden ? 'Einblenden' : 'Ausblenden', icon: m.hidden ? 'fa-eye' : 'fa-eye-slash', action: () => setMeta(id, { hidden: !m.hidden }) },
      { label: 'Produkt-ID kopieren', icon: 'fa-copy', action: () => navigator.clipboard?.writeText(p.id) },
      '-',
      { heading: 'Verschieben nach' },
      ...layout.groups.filter((g) => g.id !== current).map((g) => ({ label: g.name, icon: g.icon, action: () => moveItem(id, g.id) })),
      current !== UNSORTED ? { label: 'Nicht zugeordnet', icon: 'fa-inbox', action: () => moveItem(id, UNSORTED) } : null,
    ]);
  }

  // ---------------------------------------------------------- Dialoge

  function openDialog({ title, subtitle, body, footer, onClose }) {
    closeMenu();
    const close = () => {
      modal.remove();
      doc.removeEventListener('keydown', onKey, true);
      onClose?.();
    };
    const onKey = (e) => {
      if (e.key === 'Escape') close();
    };
    const dialog = h('div', { class: 'skp-dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('div', { class: 'skp-dhead' },
        h('div', {}, h('h5', { text: title }), subtitle ? h('p', { text: subtitle }) : null),
        h('button', { type: 'button', class: 'skp-btn is-sm is-icon is-ghost', title: 'Schließen', onclick: () => close() }, icon('fa-xmark', 'fa-solid'))),
      h('div', { class: 'skp-dbody' }, body),
      h('div', { class: 'skp-dfoot' }, footer(close)));
    const modal = h('div', { class: 'skp-modal skp-scope' }, dialog);
    modal.addEventListener('pointerdown', (e) => {
      if (e.target === modal) close();
    });
    doc.addEventListener('keydown', onKey, true);
    doc.body.append(modal);
    dialog.querySelector('input, textarea, select')?.focus();
    return close;
  }

  function swatchPicker(value, { allowNone = true, noneLabel = 'Keine' } = {}) {
    let current = value || null;
    const wrap = h('div', { class: 'skp-swatches', role: 'radiogroup' });
    const paint = () => {
      for (const b of wrap.children) b.classList.toggle('is-active', (b.dataset.value || null) === current);
    };
    if (allowNone) {
      wrap.append(h('button', { type: 'button', class: 'skp-swatch is-none', title: noneLabel, 'aria-label': noneLabel, onclick: () => ((current = null), paint()) }, icon('fa-ban', 'fa-solid')));
    }
    for (const c of SWATCHES) {
      wrap.append(h('button', { type: 'button', class: 'skp-swatch', 'data-value': c, style: `--s:${c}`, title: c, 'aria-label': c, onclick: () => ((current = c), paint()) }));
    }
    paint();
    return { el: wrap, get value() { return current; } };
  }

  function openGroupDialog(gid = null) {
    const g = gid ? findGroup(gid) : null;
    const nameInput = h('input', { class: 'skp-input', value: g?.name || '', maxlength: '60', placeholder: 'z. B. Produktion, Kunden, Spielwiese' });
    const color = swatchPicker(g?.color, { noneLabel: 'Theme-Farbe' });
    let iconValue = g?.icon || 'fa-folder';
    const icons = h('div', { class: 'skp-icons', role: 'radiogroup' },
      GROUP_ICONS.map((ic) => h('button', {
        type: 'button', class: `skp-iconbtn${ic === iconValue ? ' is-active' : ''}`, title: ic.replace('fa-', ''), 'data-icon': ic,
        onclick: (e) => {
          iconValue = ic;
          for (const b of icons.children) b.classList.toggle('is-active', b.dataset.icon === ic);
          e.currentTarget.blur();
        },
      }, icon(ic))));
    const auto = h('select', { class: 'skp-select' },
      h('option', { value: '', text: 'Nein' }),
      CATEGORIES.map((c) => h('option', { value: c.id, text: `Neue Produkte: ${c.name}`, selected: g?.auto === c.id ? true : null })));

    const submit = (close) => {
      const name = nameInput.value.trim() || 'Neue Gruppe';
      update((l) => {
        if (auto.value) for (const x of l.groups) if (x.auto === auto.value) x.auto = null;
        if (g) {
          const target = findGroup(g.id);
          Object.assign(target, { name: name.slice(0, 60), color: color.value, icon: iconValue, auto: auto.value || null });
        } else {
          l.groups.unshift({ id: uid(), name: name.slice(0, 60), color: color.value, icon: iconValue, collapsed: false, auto: auto.value || null, items: [] });
        }
      });
      close();
    };
    nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') submit(closeFn);
    });

    const closeFn = openDialog({
      title: g ? 'Gruppe bearbeiten' : 'Neue Gruppe',
      body: [
        h('label', { class: 'skp-field' }, h('span', { text: 'Name' }), nameInput),
        h('div', { class: 'skp-field' }, h('span', { text: 'Farbe' }), color.el),
        h('div', { class: 'skp-field' }, h('span', { text: 'Icon' }), icons),
        h('label', { class: 'skp-field' }, h('span', { text: 'Neue Produkte automatisch hier einsortieren' }), auto),
      ],
      footer: (close) => [
        g ? h('button', { type: 'button', class: 'skp-btn is-danger', onclick: () => { close(); deleteGroup(g.id); } }, icon('fa-trash', 'fa-solid'), 'Löschen') : null,
        h('span', { class: 'skp-spacer' }),
        h('button', { type: 'button', class: 'skp-btn', onclick: close }, 'Abbrechen'),
        h('button', { type: 'button', class: 'skp-btn is-primary', onclick: () => submit(close) }, g ? 'Speichern' : 'Gruppe anlegen'),
      ],
    });
  }

  function openItemDialog(id) {
    const p = byId.get(id);
    if (!p) return;
    const m = layout.meta[id] || {};
    const original = baseName(p);
    const alias = h('input', { class: 'skp-input', value: m.alias || '', maxlength: '80', placeholder: original });
    const tags = h('input', { class: 'skp-input', value: (m.tags || []).join(', '), placeholder: 'z. B. prod, kunde-a, backup' });
    const note = h('textarea', { class: 'skp-input', maxlength: '1000', placeholder: 'Eigene Notiz (nur lokal gespeichert)' });
    note.value = m.note || '';
    const color = swatchPicker(m.color, { noneLabel: 'Keine Markierung' });
    const current = groupOfItem(id);
    const group = h('select', { class: 'skp-select' },
      layout.groups.map((g) => h('option', { value: g.id, text: g.name, selected: g.id === current ? true : null })),
      h('option', { value: UNSORTED, text: 'Nicht zugeordnet', selected: current === UNSORTED ? true : null }));
    const hidden = h('input', { type: 'checkbox', checked: m.hidden ? true : null });

    openDialog({
      title: 'Produkt anpassen',
      subtitle: `${typeInfo(p.type).label} · ${original} · ${p.id}`,
      body: [
        h('label', { class: 'skp-field' }, h('span', { text: 'Anzeigename' }), alias,
          h('p', { class: 'skp-hint', text: 'Nur in dieser Ansicht – der Name bei skrime bleibt unverändert.' })),
        h('div', { class: 'skp-row2' },
          h('label', { class: 'skp-field' }, h('span', { text: 'Tags (kommagetrennt)' }), tags),
          h('label', { class: 'skp-field' }, h('span', { text: 'Gruppe' }), group)),
        h('label', { class: 'skp-field' }, h('span', { text: 'Notiz' }), note),
        h('div', { class: 'skp-field' }, h('span', { text: 'Farbmarkierung' }), color.el),
        h('label', { class: 'skp-check' }, hidden, h('span', { text: 'In der Übersicht ausblenden' })),
      ],
      footer: (close) => [
        h('button', { type: 'button', class: 'skp-btn', title: 'Name, Tags, Notiz und Farbe entfernen', onclick: () => {
          update((l) => delete l.meta[id]);
          close();
        } }, icon('fa-rotate-left', 'fa-solid'), 'Zurücksetzen'),
        h('span', { class: 'skp-spacer' }),
        h('button', { type: 'button', class: 'skp-btn', onclick: close }, 'Abbrechen'),
        h('button', { type: 'button', class: 'skp-btn is-primary', onclick: () => {
          const next = cleanMeta({ alias: alias.value, tags: tags.value.split(','), note: note.value.trim(), color: color.value, hidden: hidden.checked });
          update((l) => {
            if (Object.keys(next).length) l.meta[id] = next;
            else delete l.meta[id];
            if (group.value !== current) {
              for (const g of l.groups) g.items = g.items.filter((x) => x !== id);
              l.unsorted = l.unsorted.filter((x) => x !== id);
              listOf(group.value)?.push(id);
            }
          });
          close();
        } }, 'Speichern'),
      ],
    });
  }

  function regroupByType() {
    if (!confirm('Alle Gruppen entfernen und Produkte neu nach Typ gruppieren? Eigene Namen, Tags und Notizen bleiben erhalten.')) return;
    update((l) => {
      l.groups = [];
      l.unsorted = [];
      l.initialized = false;
      reconcile();
    });
  }

  function exportLayout() {
    const data = JSON.stringify({ skrimeDashboardLayout: 1, ...layout, rev: undefined }, null, 2);
    const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
    h('a', { href: url, download: 'skrime-dashboard-layout.json' }).click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function importLayout() {
    const input = h('input', { type: 'file', accept: '.json,application/json' });
    input.addEventListener('change', async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        if (file.size > 1_000_000) throw new Error('Datei ist zu groß');
        const raw = JSON.parse(await file.text());
        const next = normalizeLayout(raw);
        next.prefs.enabled = true;
        next.initialized = true;
        layout = next;
        reconcile();
        save();
        render();
      } catch (err) {
        alert(`Import fehlgeschlagen: ${err.message}`);
      }
    });
    input.click();
  }

  // ------------------------------------------------------- Drag & Drop

  const dropMarker = h('div', { class: 'skp-drop', 'aria-hidden': 'true' });

  function itemAfterPointer(body, x, y) {
    const items = [...body.querySelectorAll(':scope > .skp-item:not(.is-dragging)')];
    if (prefs().view === 'cards') {
      return items.find((it) => {
        const r = it.getBoundingClientRect();
        return y < r.top || (y <= r.bottom && x < r.left + r.width / 2);
      }) || null;
    }
    return items.find((it) => {
      const r = it.getBoundingClientRect();
      return y < r.top + r.height / 2;
    }) || null;
  }

  function groupAfterPointer(y) {
    const groups = [...groupsEl.querySelectorAll(':scope > .skp-group:not(.is-dragging)')].filter((g) => g.dataset.gid !== UNSORTED);
    return groups.find((g) => {
      const r = g.getBoundingClientRect();
      return y < r.top + r.height / 2;
    }) || null;
  }

  function clearTargets() {
    for (const el of groupsEl.querySelectorAll('.is-target')) el.classList.remove('is-target');
  }

  function ensureUnsortedTarget() {
    if (groupsEl.querySelector(`.skp-group[data-gid="${UNSORTED}"]`)) return;
    const el = renderGroup(unsortedGroup(), false);
    if (el) groupsEl.append(el);
  }

  function onDragStart(e) {
    const item = e.target.closest?.('.skp-item');
    const head = !item && e.target.closest?.('.skp-ghead');
    if (item) {
      ui.drag = { kind: 'item', id: item.dataset.id };
      item.classList.add('is-dragging');
    } else if (head) {
      const group = head.closest('.skp-group');
      ui.drag = { kind: 'group', gid: group.dataset.gid };
      group.classList.add('is-dragging');
    } else {
      return;
    }
    closeMenu();
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', ui.drag.id || ui.drag.gid);
    if (ui.drag.kind === 'item') requestAnimationFrame(ensureUnsortedTarget);
  }

  function onDragOver(e) {
    if (!ui.drag) return;
    if (ui.drag.kind === 'item') {
      const groupEl = e.target.closest?.('.skp-group');
      if (!groupEl) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      clearTargets();
      groupEl.classList.add('is-target');
      const gid = groupEl.dataset.gid;
      if (groupEl.classList.contains('is-collapsed')) {
        dropMarker.remove();
        ui.drop = { gid, before: null };
        return;
      }
      const body = groupEl.querySelector('.skp-gbody');
      const before = prefs().sort === 'manual' ? itemAfterPointer(body, e.clientX, e.clientY) : null;
      ui.drop = { gid, before: before?.dataset.id || null };
      body.querySelector(':scope > .skp-empty')?.classList.add('skp-hidden');
      if (dropMarker.parentNode !== body || dropMarker.nextSibling !== before) body.insertBefore(dropMarker, before);
    } else {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const before = groupAfterPointer(e.clientY);
      ui.drop = { before: before?.dataset.gid || null };
      const anchor = before || groupsEl.querySelector(`:scope > .skp-group[data-gid="${UNSORTED}"]`);
      if (dropMarker.parentNode !== groupsEl || dropMarker.nextSibling !== anchor) groupsEl.insertBefore(dropMarker, anchor);
    }
  }

  function onDrop(e) {
    if (!ui.drag || !ui.drop) return;
    e.preventDefault();
    const { drag, drop } = ui;
    endDrag(false);
    if (drag.kind === 'item') moveItem(drag.id, drop.gid, drop.before);
    else moveGroup(drag.gid, drop.before);
  }

  function endDrag(doRender = true) {
    if (!ui.drag) return;
    ui.drag = null;
    ui.drop = null;
    dropMarker.remove();
    if (doRender || renderPending) render();
  }

  // ------------------------------------------------------------- Aufbau

  function buildPanel() {
    const search = h('input', { class: 'skp-input', type: 'search', placeholder: 'Suchen: Name, Tag, Notiz, Domain, ID…', 'aria-label': 'Produkte durchsuchen' });
    search.addEventListener('input', debounce(() => {
      ui.search = search.value;
      render();
    }, 120));

    subEl = h('span', { text: 'Lädt…' });
    chipsEl = h('div', { class: 'skp-chips' });
    segEl = h('div', { class: 'skp-seg', role: 'group', 'aria-label': 'Ansicht' },
      VIEWS.map((v) => h('button', { type: 'button', 'data-view': v.id, title: v.label, 'aria-label': v.label, onclick: () => update((l) => (l.prefs.view = v.id)) }, icon(v.icon, 'fa-solid'))));
    sortEl = h('select', { class: 'skp-select', 'aria-label': 'Sortierung' }, SORTS.map((s) => h('option', { value: s.id, text: s.label })));
    sortEl.addEventListener('change', () => update((l) => (l.prefs.sort = sortEl.value)));

    groupsEl = h('div', { class: 'skp-groups' });
    groupsEl.addEventListener('dragstart', onDragStart);
    groupsEl.addEventListener('dragover', onDragOver);
    groupsEl.addEventListener('drop', onDrop);
    groupsEl.addEventListener('dragend', () => endDrag());

    rootEl = h('section', { class: 'skp skp-scope', 'aria-label': 'Produkte in Gruppen' },
      h('div', { class: 'skp-bar' },
        h('div', { class: 'skp-title' }, h('h5', { text: 'Meine Produkte' }), subEl),
        h('div', { class: 'skp-search' }, icon('fa-magnifying-glass', 'fa-solid'), search),
        chipsEl,
        segEl,
        sortEl,
        h('button', { type: 'button', class: 'skp-btn is-primary', onclick: () => openGroupDialog() }, icon('fa-plus', 'fa-solid'), 'Gruppe'),
        h('button', { type: 'button', class: 'skp-btn is-icon', title: 'Ansicht & Layout', 'aria-label': 'Ansicht & Layout', onclick: (e) => openMainMenu(e.currentTarget) }, icon('fa-sliders', 'fa-solid'))),
      groupsEl);
    return rootEl;
  }

  function applyEnabled() {
    const on = prefs().enabled;
    // Konnten die Produkte nicht geladen werden, bleibt die Original-Ansicht zusätzlich sichtbar.
    const failed = !productsLoaded && !!loadError;
    rootEl.parentElement?.classList.toggle('skp-hidden', !on);
    restoreEl?.classList.toggle('skp-hidden', on);
    for (const el of originals) el.classList.toggle('skp-hidden', on && !failed);
  }

  function mount() {
    const pills = doc.getElementById('pills-tab');
    const content = doc.getElementById('pills-tabContent');
    if (!pills || !content || rootEl) return;
    originals = [...new Set([pills.closest('.col-md-12') || pills, content.closest('.col-md-12') || content])];

    const col = h('div', { class: 'col-md-12 mt-3' }, buildPanel());
    restoreEl = h('div', { class: 'col-md-12 skp-scope skp-restore' },
      h('button', { type: 'button', class: 'skp-btn', onclick: () => update((l) => (l.prefs.enabled = true)) }, icon('fa-layer-group'), 'Gruppenansicht aktivieren'));
    originals[0].before(col, restoreEl);

    SKT.registerColors?.(PANEL_COLORS);
    statusMap = readStatuses();
    new MutationObserver(debounce(onSkrimeUpdate, 300)).observe(content, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'data-bs-original-title'],
    });
    render();
    loadProducts();
    setInterval(() => {
      if (doc.visibilityState === 'visible' && !ui.drag) loadProducts();
    }, REFRESH_MS);
  }

  // ------------------------------------------------------------ Start

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !(STORAGE_KEY in changes)) return;
    const next = changes[STORAGE_KEY].newValue;
    if (next?.rev && next.rev === lastWrittenRev) return;
    layout = normalizeLayout(next);
    reconcile();
    render();
  });

  api.storage.local.get(STORAGE_KEY).then((s) => {
    layout = normalizeLayout(s[STORAGE_KEY]);
    if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', mount, { once: true });
    else mount();
  });
})();
