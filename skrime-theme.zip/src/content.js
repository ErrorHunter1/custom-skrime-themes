/*
 * Content-Script für skrime.eu (läuft ab document_start).
 *
 * Ablauf:
 *  1. Seite kurz ausblenden ("Cloak"), damit das Original-Theme nicht aufblitzt.
 *  2. Alle Stylesheets von skrime.eu werden geladen, mit SKT.rewriteCss auf
 *     CSS-Variablen umgeschrieben (Ergebnis wird in storage.local gecacht) und
 *     anstelle des Originals eingefügt. Das Original wird per media="not all"
 *     deaktiviert.
 *  3. Das aktive Theme setzt nur die --skt-* Variablen -> Theme-Wechsel und
 *     Live-Vorschau sind sofort sichtbar, ohne die Sheets neu zu verarbeiten.
 */
(() => {
  'use strict';
  const SKT = globalThis.SKT;
  if (!SKT || globalThis.__sktContentLoaded) return;
  globalThis.__sktContentLoaded = true;

  const api = globalThis.browser ?? globalThis.chrome;
  const doc = document;
  const html = doc.documentElement;
  const ATTR = 'data-skt';
  const CACHE_PREFIX = `css${SKT.REWRITER_VERSION}:`;
  const SHEET_SELECTOR = 'link[rel~="stylesheet"], style';

  const memCache = new Map(); // href -> Promise<{css, colors, changed}>
  const links = new Map(); // <link> -> {style, media}
  const inlineStyles = new Map(); // <style> -> Originaltext
  const knownColors = new Set();
  const pending = new Set();

  let enabled = false;
  let theme = null;
  let previewTheme = null;
  let renderQueued = false;
  let domReady = doc.readyState !== 'loading';

  const make = (tag, role) => {
    const el = doc.createElement(tag);
    el.setAttribute(ATTR, role);
    return el;
  };

  // --- 1. Cloak (mit CSS-Failsafe: spätestens nach 1,5 s wird eingeblendet)
  const cloak = make('style', 'cloak');
  cloak.textContent =
    '@keyframes skt-reveal{to{opacity:1}}' +
    'html:not([data-skt-ready]) body{opacity:0;animation:skt-reveal 1ms 1.5s forwards}';
  if (!domReady) html.appendChild(cloak);

  const varsEl = make('style', 'vars');
  const userEl = make('style', 'user');
  let fontEl = null;

  function reveal() {
    if (!domReady || pending.size) return;
    html.setAttribute('data-skt-ready', '');
    cloak.remove();
  }

  function track(promise) {
    pending.add(promise);
    promise
      .catch((err) => console.warn('[Skrime Themes]', err))
      .finally(() => {
        pending.delete(promise);
        reveal();
      });
    return promise;
  }

  // --- 2. Stylesheet-Cache (Aufräumen alter Einträge übernimmt background.js)

  async function loadSheet(href) {
    const key = CACHE_PREFIX + href;
    const stored = (await api.storage.local.get(key))[key];
    if (stored) return stored;
    const res = await fetch(href, { credentials: 'same-origin' });
    if (!res.ok) throw new Error(`${href}: HTTP ${res.status}`);
    const result = SKT.rewriteCss(await res.text(), href);
    const entry = result.changed ? result : { css: '', colors: [], changed: false };
    entry.t = Date.now();
    try {
      await api.storage.local.set({ [key]: entry });
    } catch (err) {
      // z.B. Speicher voll – das Theme funktioniert trotzdem, nur ohne Cache.
      console.warn('[Skrime Themes] Cache nicht gespeichert:', err);
    }
    return entry;
  }

  function getSheet(href) {
    let p = memCache.get(href);
    if (!p) {
      p = loadSheet(href);
      memCache.set(href, p);
      p.catch(() => memCache.delete(href));
    }
    return p;
  }

  // --- Verarbeitung von <link> und <style>

  const isSkrimeUrl = (href) => {
    try {
      const u = new URL(href);
      return u.protocol === 'https:' && /(^|\.)skrime\.eu$/i.test(u.hostname);
    } catch {
      return false;
    }
  };

  function processLink(link) {
    if (links.has(link) || link.hasAttribute(ATTR) || !link.href || !isSkrimeUrl(link.href)) return;
    if (!/(^|\s)stylesheet(\s|$)/i.test(link.rel)) return;
    const entry = { style: null, media: link.getAttribute('media') };
    links.set(link, entry);
    track(
      getSheet(link.href).then((res) => {
        if (!enabled || links.get(link) !== entry || !res.changed || !link.isConnected) return;
        const style = make('style', 'sheet');
        style.dataset.sktHref = link.href;
        if (entry.media) style.media = entry.media;
        style.textContent = res.css;
        link.after(style);
        link.setAttribute('media', 'not all');
        entry.style = style;
        addColors(res.colors);
      })
    );
  }

  function processInlineStyle(el) {
    if (el.hasAttribute(ATTR) || inlineStyles.has(el)) return;
    const text = el.textContent;
    if (!text || text.length > 1_000_000) return;
    const res = SKT.rewriteCss(text, doc.baseURI);
    if (!res.changed) return;
    inlineStyles.set(el, text);
    el.textContent = res.css;
    addColors(res.colors);
  }

  function scan(el) {
    if (el.tagName === 'LINK') processLink(el);
    else if (el.tagName === 'STYLE') processInlineStyle(el);
  }

  function scanAll() {
    doc.querySelectorAll(SHEET_SELECTOR).forEach(scan);
  }

  new MutationObserver((records) => {
    if (!enabled) return;
    for (const r of records) {
      for (const node of r.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.tagName === 'LINK' || node.tagName === 'STYLE') scan(node);
        else if (node.firstElementChild) node.querySelectorAll(SHEET_SELECTOR).forEach(scan);
      }
    }
  }).observe(doc, { childList: true, subtree: true });

  // --- 3. Theme anwenden

  function addColors(list) {
    let added = false;
    for (const c of list) {
      if (!knownColors.has(c)) {
        knownColors.add(c);
        added = true;
      }
    }
    if (added) scheduleRender();
  }

  // Erweiterungen wie die Dashboard-Gruppen melden hier ihre (Original-)Farben
  // an, damit dafür ebenfalls --skt-* Variablen erzeugt werden.
  SKT.registerColors = (list) => addColors(list);

  function scheduleRender() {
    if (renderQueued) return;
    renderQueued = true;
    queueMicrotask(render);
  }

  /** Eigene Styles ans Ende von <html> hängen, damit sie in der Kaskade zuletzt kommen. */
  function placeStyles() {
    if (fontEl) html.appendChild(fontEl);
    html.appendChild(varsEl);
    html.appendChild(userEl);
  }

  function render() {
    renderQueued = false;
    const t = previewTheme || theme;
    if (!enabled || !t) return;

    const palette = SKT.buildPalette(t.colors, knownColors);
    let vars = '';
    for (const hex in palette) vars += `--skt-${hex}:${palette[hex]};`;
    if (t.font) vars += `--skt-font:"${t.font}";`;
    let css = `:root:root{${vars}}`;
    if (t.tintImages) {
      const deg = SKT.primaryHueShift(t.colors);
      if (Math.abs(deg) >= 2) css += `section img.img-fluid{filter:hue-rotate(${deg.toFixed(1)}deg)}`;
    }
    varsEl.textContent = css;
    userEl.textContent = t.css || '';

    if (t.fontUrl) {
      if (!fontEl) {
        fontEl = make('link', 'font');
        fontEl.rel = 'stylesheet';
      }
      if (fontEl.getAttribute('href') !== t.fontUrl) fontEl.href = t.fontUrl;
    } else if (fontEl) {
      fontEl.remove();
      fontEl = null;
    }
    if (!varsEl.isConnected || (fontEl && !fontEl.isConnected)) placeStyles();
  }

  function teardown() {
    for (const [link, entry] of links) {
      entry.style?.remove();
      if (entry.style) {
        if (entry.media === null) link.removeAttribute('media');
        else link.setAttribute('media', entry.media);
      }
    }
    links.clear();
    for (const [el, text] of inlineStyles) el.textContent = text;
    inlineStyles.clear();
    varsEl.remove();
    userEl.remove();
    fontEl?.remove();
  }

  function setEnabled(on) {
    if (on === enabled) return;
    enabled = on;
    if (on) {
      scanAll();
      scheduleRender();
    } else {
      teardown();
    }
  }

  async function sync() {
    const s = await api.storage.local.get(['settings', 'userThemes', 'sourceThemes']);
    const settings = { ...SKT.DEFAULT_SETTINGS, ...(s.settings || {}) };
    theme = SKT.resolveTheme({ ...s, settings });
    setEnabled(previewTheme ? true : settings.enabled !== false);
    scheduleRender();
  }

  if (!domReady) {
    doc.addEventListener(
      'DOMContentLoaded',
      () => {
        domReady = true;
        if (enabled) {
          scanAll();
          placeStyles();
        }
        reveal();
      },
      { once: true }
    );
  }

  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.settings || changes.userThemes || changes.sourceThemes)) track(sync());
  });

  // Live-Vorschau aus dem Theme-Editor (wird nicht gespeichert). Schließt der
  // Editor, trennt sich der Port und das gespeicherte Theme gilt wieder.
  api.runtime.onConnect.addListener((port) => {
    if (port.name !== 'skt-preview') return;
    port.onMessage.addListener((msg) => {
      previewTheme = msg?.theme || null;
      track(sync());
    });
    port.onDisconnect.addListener(() => {
      previewTheme = null;
      track(sync());
    });
  });

  track(sync());
})();
