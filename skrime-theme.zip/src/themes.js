/*
 * Theme-Modell: Vorlagen, Validierung/Normalisierung, Import-Format und
 * Sicherheitsprüfung für eigenes CSS aus fremden Quellen.
 */
(function (root) {
  'use strict';
  const SKT = (root.SKT = root.SKT || {});

  SKT.FORMAT_VERSION = 1;
  SKT.DEFAULT_THEME_ID = 'midnight-violet';
  SKT.MAX_CSS_LENGTH = 100000;

  SKT.ROLE_LABELS = {
    primary: 'Primärfarbe',
    accent: 'Akzent (Verlauf)',
    background: 'Hintergrund',
    surface: 'Flächen / Karten',
    border: 'Rahmen',
    text: 'Text',
    muted: 'Text gedämpft',
    secondary: 'Sekundär',
    success: 'Erfolg',
    danger: 'Fehler',
    warning: 'Warnung',
    info: 'Info',
  };

  const preset = (id, name, colors, extra = {}) =>
    Object.freeze({ id, name, author: 'Skrime Themes', kind: 'preset', colors: Object.freeze(colors), font: '', fontUrl: '', tintImages: true, css: '', ...extra });

  SKT.PRESETS = Object.freeze([
    preset('skrime-original', 'Skrime Original', { ...SKT.ORIGINAL_COLORS }, { tintImages: false }),
    preset('midnight-violet', 'Midnight Violet', {
      primary: '#7c3aed', accent: '#c026d3', background: '#0d0b14', surface: '#14111d', border: '#272036',
      text: '#f5f3ff', muted: '#a69dc4', secondary: '#d6d0e8', success: '#22c55e', danger: '#f43f5e', warning: '#f59e0b', info: '#06b6d4',
    }),
    preset('emerald-night', 'Emerald Night', {
      primary: '#059669', accent: '#0891b2', background: '#08110e', surface: '#0d1915', border: '#1c2c26',
      text: '#ecfdf5', muted: '#91b5a7', secondary: '#cfe4db', success: '#22c55e', danger: '#ef4444', warning: '#f59e0b', info: '#0ea5e9',
    }),
    preset('sunset-ember', 'Sunset Ember', {
      primary: '#ea580c', accent: '#be123c', background: '#120c0a', surface: '#1b1310', border: '#34241e',
      text: '#fff7ed', muted: '#c8a796', secondary: '#ebd8cd', success: '#16a34a', danger: '#e11d48', warning: '#f59e0b', info: '#0891b2',
    }),
    preset('nord', 'Nord', {
      primary: '#5e81ac', accent: '#b48ead', background: '#2e3440', surface: '#3b4252', border: '#4c566a',
      text: '#eceff4', muted: '#aab4c5', secondary: '#d8dee9', success: '#7fa36a', danger: '#bf616a', warning: '#d08770', info: '#4c9bb0',
    }),
    preset('dracula', 'Dracula', {
      primary: '#9466e8', accent: '#e0559e', background: '#1e1f29', surface: '#282a36', border: '#44475a',
      text: '#f8f8f2', muted: '#a7aed3', secondary: '#d9d9ea', success: '#2fb86a', danger: '#ff5555', warning: '#f0a35e', info: '#3fb5d0',
    }),
    preset('rose-pine', 'Rosé Pine', {
      primary: '#c0587e', accent: '#9b72cf', background: '#191724', surface: '#1f1d2e', border: '#2f2b45',
      text: '#e0def4', muted: '#908caa', secondary: '#c9c6e0', success: '#3e8fb0', danger: '#eb6f92', warning: '#f6c177', info: '#56a4b3',
    }),
    preset('oled-black', 'OLED Schwarz', {
      primary: '#2563eb', accent: '#4f46e5', background: '#000000', surface: '#0a0a0b', border: '#1f1f23',
      text: '#fafafa', muted: '#a1a1aa', secondary: '#d4d4d8', success: '#22c55e', danger: '#ef4444', warning: '#f97316', info: '#06b6d4',
    }),
  ]);

  // ------------------------------------------------------------- Hilfsfunktionen

  /** Kleiner, stabiler String-Hash (für IDs und CSS-Freigaben). */
  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  function slug(str) {
    return String(str || 'theme')
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[^\w\s-]/g, '')
      .trim()
      .replace(/[\s_]+/g, '-')
      .slice(0, 40) || 'theme';
  }

  const cleanText = (v, max) => String(v ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);
  const cleanFont = (v) => String(v ?? '').replace(/[^\w \-]/g, '').trim().slice(0, 60);

  const FONT_HOSTS = ['https://fonts.bunny.net/', 'https://fonts.googleapis.com/'];

  /** Bunny Fonts (DSGVO-freundlicher Google-Fonts-Ersatz) als Standard-Quelle. */
  function fontUrlFor(font) {
    const f = cleanFont(font);
    if (!f) return '';
    return `https://fonts.bunny.net/css?family=${encodeURIComponent(f.toLowerCase()).replace(/%20/g, '-')}:400,600,700&display=swap`;
  }

  /**
   * Prüft fremdes CSS auf Konstrukte, die Netzwerkanfragen auslösen können
   * (url(), @import, image-set ...). Damit ließen sich z.B. Formularinhalte
   * aus dem eingeloggten Kundenbereich an fremde Server senden.
   * @returns {string|null} Grund, falls blockiert
   */
  function cssRisk(css) {
    if (!css) return null;
    const decoded = String(css)
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/\\([0-9a-fA-F]{1,6})\s?/g, (_, h) => {
        try { return String.fromCodePoint(parseInt(h, 16)); } catch { return ''; }
      })
      .replace(/\\(.)/g, '$1')
      .toLowerCase();
    if (/@import/.test(decoded)) return '@import';
    if (/image-set\s*\(|cross-fade\s*\(|element\s*\(/.test(decoded)) return 'image-set/element()';
    const withoutDataUrls = decoded.replace(/url\(\s*(["']?)data:image\/[^)]*\)/g, '');
    if (/url\s*\(/.test(withoutDataUrls)) return 'externe url()';
    return null;
  }

  /**
   * Validiert und normalisiert ein Theme-Objekt.
   * @param {object} raw
   * @param {{trusted?: boolean, kind?: string, idPrefix?: string}} opts
   *   trusted=false: CSS mit externen Ressourcen wird zurückgehalten, bis der
   *   Nutzer es im Editor freigibt.
   */
  function normalizeTheme(raw, opts = {}) {
    if (!raw || typeof raw !== 'object') throw new Error('Theme ist kein Objekt');
    const name = cleanText(raw.name, 60) || 'Unbenanntes Theme';
    const srcColors = raw.colors && typeof raw.colors === 'object' ? raw.colors : {};
    const colors = {};
    let valid = 0;
    for (const role of SKT.ROLES) {
      const hex = SKT.normalizeHex(srcColors[role]);
      if (hex) valid++;
      colors[role] = hex || SKT.ORIGINAL_COLORS[role];
    }
    if (!valid) throw new Error(`Theme „${name}“ enthält keine gültigen Farben`);

    const baseId = cleanText(raw.id, 60).replace(/[^\w:-]/g, '') || slug(name);
    const id = opts.idPrefix ? `${opts.idPrefix}${baseId}` : baseId;
    const font = cleanFont(raw.font);
    let fontUrl = String(raw.fontUrl || '').trim();
    if (fontUrl && !FONT_HOSTS.some((h) => fontUrl.startsWith(h))) fontUrl = '';
    if (!fontUrl && font) fontUrl = fontUrlFor(font);

    let css = typeof raw.css === 'string' ? raw.css.slice(0, SKT.MAX_CSS_LENGTH) : '';
    const theme = {
      id,
      name,
      author: cleanText(raw.author, 60),
      description: cleanText(raw.description, 200),
      kind: opts.kind || raw.kind || 'user',
      colors,
      font,
      fontUrl,
      tintImages: raw.tintImages !== false,
      css: '',
    };
    if (opts.source) theme.source = opts.source;

    const risk = opts.trusted === false ? cssRisk(css) : null;
    if (risk) {
      theme.blockedCss = css;
      theme.blockedReason = risk;
    } else {
      theme.css = css;
    }
    return theme;
  }

  /** Akzeptiert ein Theme, ein Array von Themes oder {name?, themes: [...]}. */
  function parseThemePayload(data, opts = {}) {
    if (typeof data === 'string') data = JSON.parse(data);
    const list = Array.isArray(data) ? data : Array.isArray(data?.themes) ? data.themes : [data];
    const themes = [];
    const errors = [];
    for (const item of list) {
      try {
        themes.push(normalizeTheme(item, opts));
      } catch (e) {
        errors.push(e.message);
      }
    }
    if (!themes.length) throw new Error(errors[0] || 'Keine Themes gefunden');
    return { name: cleanText(data?.name, 60), themes, errors };
  }

  /** Exportformat (ohne interne Felder). */
  function exportTheme(theme) {
    const out = { skrimeTheme: SKT.FORMAT_VERSION, id: theme.id.replace(/^(user|src-[\w]+):/, ''), name: theme.name };
    if (theme.author) out.author = theme.author;
    if (theme.description) out.description = theme.description;
    out.colors = { ...theme.colors };
    if (theme.font) out.font = theme.font;
    if (theme.fontUrl && theme.fontUrl !== fontUrlFor(theme.font)) out.fontUrl = theme.fontUrl;
    out.tintImages = theme.tintImages !== false;
    if (theme.css) out.css = theme.css;
    return out;
  }

  /** Ermittelt das aktive Theme aus dem gespeicherten Zustand. */
  function resolveTheme(state) {
    const id = state?.settings?.activeThemeId || SKT.DEFAULT_THEME_ID;
    return (
      state?.userThemes?.[id] ||
      state?.sourceThemes?.[id] ||
      SKT.PRESETS.find((p) => p.id === id) ||
      SKT.PRESETS.find((p) => p.id === SKT.DEFAULT_THEME_ID)
    );
  }

  /** Alle Themes, gruppiert für Listen in Popup/Editor. */
  function allThemes(state) {
    return {
      presets: [...SKT.PRESETS],
      user: Object.values(state?.userThemes || {}).sort((a, b) => a.name.localeCompare(b.name)),
      sources: Object.values(state?.sourceThemes || {}).sort((a, b) => a.name.localeCompare(b.name)),
    };
  }

  SKT.DEFAULT_SETTINGS = Object.freeze({ enabled: true, activeThemeId: SKT.DEFAULT_THEME_ID, livePreview: true });

  Object.assign(SKT, {
    hash,
    slug,
    fontUrlFor,
    cssRisk,
    normalizeTheme,
    parseThemePayload,
    exportTheme,
    resolveTheme,
    allThemes,
  });
})(typeof globalThis !== 'undefined' ? globalThis : this);
