/*
 * Theme-Quellen ("Theme-API"): Eine Quelle ist eine URL, die JSON im
 * Skrime-Themes-Format liefert. Quellen werden regelmäßig im Hintergrund
 * aktualisiert. Genutzt von background.js und der Optionsseite.
 */
(function (root) {
  'use strict';
  const SKT = (root.SKT = root.SKT || {});
  const api = root.browser ?? root.chrome;

  function sourcePrefix(url) {
    return `src-${SKT.hash(url)}:`;
  }

  async function fetchJson(url) {
    const res = await fetch(url, { cache: 'no-cache', credentials: 'omit', headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    if (text.length > 2_000_000) throw new Error('Antwort zu groß');
    try {
      return JSON.parse(text);
    } catch {
      throw new Error('Antwort ist kein gültiges JSON');
    }
  }

  /** Lädt Themes von einer URL (ohne zu speichern). */
  async function loadFromUrl(url, opts = {}) {
    const u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) throw new Error('Nur http(s)-URLs sind erlaubt');
    const data = await fetchJson(u.href);
    return SKT.parseThemePayload(data, { trusted: false, kind: 'source', ...opts });
  }

  /** Übernimmt vom Nutzer freigegebenes CSS, solange es sich nicht geändert hat. */
  function applyApprovals(themes, approvedCss) {
    for (const t of themes) {
      if (t.blockedCss && approvedCss?.[t.id] === SKT.hash(t.blockedCss)) {
        t.css = t.blockedCss;
        delete t.blockedCss;
        delete t.blockedReason;
      }
    }
    return themes;
  }

  /** Aktualisiert alle (oder eine) Quelle und speichert das Ergebnis. */
  async function refreshSources(onlyUrl) {
    const state = await api.storage.local.get(['sources', 'sourceThemes', 'approvedCss']);
    const sources = state.sources || [];
    const sourceThemes = state.sourceThemes || {};
    for (const src of sources) {
      if (onlyUrl && src.url !== onlyUrl) continue;
      try {
        const prefix = sourcePrefix(src.url);
        const { name, themes } = await loadFromUrl(src.url, { idPrefix: prefix, source: src.url });
        applyApprovals(themes, state.approvedCss);
        for (const id of Object.keys(sourceThemes)) if (id.startsWith(prefix)) delete sourceThemes[id];
        for (const t of themes) sourceThemes[t.id] = t;
        src.name = name || src.name || new URL(src.url).hostname;
        src.count = themes.length;
        src.lastFetched = Date.now();
        src.error = null;
      } catch (e) {
        src.error = String(e?.message || e);
        src.lastFetched = Date.now();
      }
    }
    await api.storage.local.set({ sources, sourceThemes });
    return sources;
  }

  async function addSource(url) {
    const href = new URL(url).href;
    const { sources = [] } = await api.storage.local.get('sources');
    if (!sources.some((s) => s.url === href)) {
      sources.push({ url: href, name: new URL(href).hostname, lastFetched: 0, error: null, count: 0 });
      await api.storage.local.set({ sources });
    }
    return refreshSources(href);
  }

  async function removeSource(url) {
    const state = await api.storage.local.get(['sources', 'sourceThemes', 'settings']);
    const prefix = sourcePrefix(url);
    const sources = (state.sources || []).filter((s) => s.url !== url);
    const sourceThemes = state.sourceThemes || {};
    for (const id of Object.keys(sourceThemes)) if (id.startsWith(prefix)) delete sourceThemes[id];
    const update = { sources, sourceThemes };
    if (state.settings?.activeThemeId?.startsWith(prefix)) {
      update.settings = { ...state.settings, activeThemeId: SKT.DEFAULT_THEME_ID };
    }
    await api.storage.local.set(update);
  }

  Object.assign(SKT, { sourcePrefix, loadFromUrl, applyApprovals, refreshSources, addSource, removeSource });
})(typeof globalThis !== 'undefined' ? globalThis : this);
