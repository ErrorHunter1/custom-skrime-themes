/*
 * CSS-Rewriter: schreibt die Stylesheets von skrime.eu einmalig so um, dass
 * jede Farbe über eine CSS-Variable läuft:
 *
 *   #2f55d4                  ->  rgb(var(--skt-2f55d4, 47, 85, 212))
 *   rgba(47, 85, 212, .1)    ->  rgba(var(--skt-2f55d4, 47, 85, 212), .1)
 *   --bs-primary-rgb: 47, 85, 212  ->  var(--skt-2f55d4, 47, 85, 212)
 *   font-family: "Nunito"    ->  var(--skt-font, "Nunito")
 *
 * Das Ergebnis ist unabhängig vom Theme (und damit cachebar). Ein Theme setzt
 * nur noch die --skt-* Variablen; ohne Theme greifen die Fallback-Werte und
 * die Seite sieht exakt aus wie das Original.
 */
(function (root) {
  'use strict';
  const SKT = (root.SKT = root.SKT || {});

  SKT.REWRITER_VERSION = 1;

  // Reines Weiß/Schwarz bleibt unangetastet (Button-Texte, Schatten, Overlays).
  const PROTECTED = new Set(['ffffff', '000000']);

  const COLOR_RE = new RegExp(
    [
      // 1) Bootstrap-RGB-Tripel in Custom Properties: --bs-primary-rgb: 47, 85, 212
      String.raw`(--[\w-]*-rgb\s*:\s*)(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?=\s*(?:;|!|$))`,
      // 2) rgb()/rgba() mit Komma- oder Leerzeichen-Syntax
      String.raw`\brgba?\(\s*(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*(?:[,/]\s*([\d.]+%?)\s*)?\)`,
      // 3) Hex-Farben (#rgb, #rgba, #rrggbb, #rrggbbaa)
      String.raw`#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})(?![\w-])`,
    ].join('|'),
    'g'
  );
  const BARE_FONT_RE = /(?<![\w-])Nunito(?![\w-])/g;
  const FONT_STRING_RE = /^(["'])nunito\1$/i;

  const hex2 = (n) => Math.max(0, Math.min(255, n | 0)).toString(16).padStart(2, '0');

  function colorRef(r, g, b, alpha, colors) {
    const hex = hex2(r) + hex2(g) + hex2(b);
    if (PROTECTED.has(hex)) return null;
    colors.add(hex);
    const ref = `var(--skt-${hex}, ${r | 0}, ${g | 0}, ${b | 0})`;
    if (alpha === undefined || alpha === '' || alpha === '1' || alpha === '100%') return `rgb(${ref})`;
    return `rgba(${ref}, ${alpha})`;
  }

  function rewriteDeclarations(text, colors, allowFont, stats) {
    const out = text.replace(COLOR_RE, (m, tPrefix, tr, tg, tb, r, g, b, a, hex) => {
      if (tPrefix !== undefined) {
        const h = hex2(+tr) + hex2(+tg) + hex2(+tb);
        if (PROTECTED.has(h)) return m;
        colors.add(h);
        return `${tPrefix}var(--skt-${h}, ${+tr}, ${+tg}, ${+tb})`;
      }
      if (r !== undefined) {
        if (+r > 255 || +g > 255 || +b > 255) return m;
        return colorRef(+r, +g, +b, a, colors) || m;
      }
      const c = SKT.parseHex(hex);
      if (!c) return m;
      const alpha = c.a < 1 ? String(Math.round(c.a * 1000) / 1000) : undefined;
      return colorRef(c.r, c.g, c.b, alpha, colors) || m;
    });
    if (!allowFont) return out;
    return out.replace(BARE_FONT_RE, () => {
      stats.fonts++;
      return 'var(--skt-font, Nunito)';
    });
  }

  function absolutizeUrl(token, base) {
    if (!base) return token;
    const m = /^url\(\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^)]*?))\s*\)$/i.exec(token);
    if (!m) return token;
    const raw = m[1] ?? m[2] ?? m[3] ?? '';
    if (!raw || /^(data:|#|about:|blob:)/i.test(raw)) return token;
    try {
      return `url("${new URL(raw, base).href.replace(/["\\]/g, '\\$&')}")`;
    } catch {
      return token;
    }
  }

  function absolutizeString(token, base) {
    try {
      const raw = token.slice(1, -1);
      return `"${new URL(raw, base).href.replace(/["\\]/g, '\\$&')}"`;
    } catch {
      return token;
    }
  }

  const isIdentChar = (c) =>
    (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 45 || c === 95 || c > 127;

  /**
   * @param {string} text  CSS-Quelltext
   * @param {string} base  URL des Stylesheets (für relative url()-Pfade)
   * @returns {{css: string, colors: string[], changed: boolean}}
   */
  function rewriteCss(text, base) {
    const colors = new Set();
    const out = [];
    const preludes = [];
    let seg = [];
    let plainStart = 0;
    const stats = { fonts: 0 };
    const n = text.length;
    let i = 0;

    const pushPlain = (end) => {
      if (end > plainStart) seg.push({ t: 'x', v: text.slice(plainStart, end) });
    };

    // Ein Segment ist der Text zwischen zwei geschweiften Klammern. Endet es
    // mit "}", ist es ein Deklarationsblock, sonst ein Selektor/@-Prelude.
    const flush = (isDecl) => {
      const parent = preludes[preludes.length - 1] || '';
      const allowFont = isDecl && !/^@font-face/i.test(parent);
      for (let k = 0; k < seg.length; k++) {
        const tok = seg[k];
        if (tok.t === 'u') {
          out.push(absolutizeUrl(tok.v, base));
        } else if (tok.t === 's') {
          if (allowFont && FONT_STRING_RE.test(tok.v)) {
            out.push(`var(--skt-font, ${tok.v})`);
            stats.fonts++;
          } else if (!isDecl && k > 0 && seg[k - 1].t === 'x' && /@import\s*$/i.test(seg[k - 1].v)) {
            out.push(absolutizeString(tok.v, base));
          } else {
            out.push(tok.v);
          }
        } else {
          out.push(isDecl ? rewriteDeclarations(tok.v, colors, allowFont, stats) : tok.v);
        }
      }
    };

    while (i < n) {
      const c = text.charCodeAt(i);

      // Kommentar – wird verworfen
      if (c === 47 && text.charCodeAt(i + 1) === 42) {
        pushPlain(i);
        const end = text.indexOf('*/', i + 2);
        i = plainStart = end < 0 ? n : end + 2;
        continue;
      }

      // String
      if (c === 34 || c === 39) {
        pushPlain(i);
        let j = i + 1;
        while (j < n) {
          const d = text.charCodeAt(j);
          if (d === 92) { j += 2; continue; }
          if (d === c || d === 10) break;
          j++;
        }
        j = Math.min(j + 1, n);
        seg.push({ t: 's', v: text.slice(i, j) });
        i = plainStart = j;
        continue;
      }

      // url(...)
      if ((c === 117 || c === 85) && !isIdentChar(text.charCodeAt(i - 1)) && /^url\(/i.test(text.substr(i, 4))) {
        pushPlain(i);
        let j = i + 4;
        while (j < n && /\s/.test(text[j])) j++;
        const q = text[j];
        if (q === '"' || q === "'") {
          j++;
          while (j < n && text[j] !== q) j += text[j] === '\\' ? 2 : 1;
          j++;
        }
        const close = text.indexOf(')', j);
        const end = close < 0 ? n : close + 1;
        seg.push({ t: 'u', v: text.slice(i, end) });
        i = plainStart = end;
        continue;
      }

      if (c === 123 || c === 125) {
        pushPlain(i);
        const isOpen = c === 123;
        const prelude = isOpen ? seg.map((t) => t.v).join('').trim() : '';
        flush(!isOpen);
        if (isOpen) preludes.push(prelude);
        else preludes.pop();
        out.push(text[i]);
        seg = [];
        i = plainStart = i + 1;
        continue;
      }

      i++;
    }
    pushPlain(n);
    flush(false);

    return { css: out.join(''), colors: [...colors], changed: colors.size > 0 || stats.fonts > 0 };
  }

  SKT.rewriteCss = rewriteCss;
})(typeof globalThis !== 'undefined' ? globalThis : this);
