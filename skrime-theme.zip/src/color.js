/*
 * Farb-Utilities: Parsing, OKLab/OKLCH-Konvertierung und das anker-basierte
 * Remapping, das die Originalpalette von skrime.eu auf ein Theme überträgt.
 *
 * Idee: Jede Farbe im Original-CSS wird ihrem nächstgelegenen "Anker"
 * (Primärfarbe, Hintergrund, Rahmen, ...) zugeordnet. Die Verschiebung
 * Anker -> Theme-Farbe (Helligkeit, Sättigung, Farbton) wird dann auf die
 * Farbe angewendet. So werden auch Hover-Töne, Schatten und Verläufe
 * stimmig mit umgefärbt, ohne dass jede Farbe einzeln gepflegt werden muss.
 */
(function (root) {
  'use strict';
  const SKT = (root.SKT = root.SKT || {});

  const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);

  /** Originalfarben von skrime.eu (Landrick Dark + skrime-Anpassungen). */
  const ORIGINAL = {
    primary: '#2f55d4',
    accent: '#614092',
    background: '#15171c',
    surface: '#1a1c21',
    border: '#2b2f36',
    text: '#f8f9fa',
    muted: '#9bacc4',
    secondary: '#ced4da',
    success: '#2eca8b',
    danger: '#e43f52',
    warning: '#f17425',
    info: '#17a2b8',
  };

  SKT.ORIGINAL_COLORS = Object.freeze({ ...ORIGINAL });
  SKT.ROLES = Object.freeze(Object.keys(ORIGINAL));

  // ---------------------------------------------------------------- Parsing

  function parseHex(hex) {
    let h = String(hex || '').trim().replace(/^#/, '');
    if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join('');
    if (!/^[0-9a-f]{6}([0-9a-f]{2})?$/i.test(h)) return null;
    const n = parseInt(h.slice(0, 6), 16);
    return {
      r: (n >> 16) & 255,
      g: (n >> 8) & 255,
      b: n & 255,
      a: h.length === 8 ? parseInt(h.slice(6), 16) / 255 : 1,
    };
  }

  function toHex({ r, g, b }) {
    return '#' + [r, g, b].map((v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  }

  /** Normalisiert Eingaben wie "#ABC" oder "abc123" auf "#aabbcc" (oder null). */
  function normalizeHex(value) {
    const c = parseHex(value);
    return c ? toHex(c) : null;
  }

  // ------------------------------------------------------------ OKLab/OKLCH

  const toLinear = (c) => {
    c /= 255;
    return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  };
  const fromLinear = (c) => 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);

  function rgbToOklab({ r, g, b }) {
    const lr = toLinear(r), lg = toLinear(g), lb = toLinear(b);
    const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
    const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
    const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
    return {
      L: 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
      a: 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
      b: 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
    };
  }

  function oklabToLinearRgb(L, a, b) {
    const l = Math.pow(L + 0.3963377774 * a + 0.2158037573 * b, 3);
    const m = Math.pow(L - 0.1055613458 * a - 0.0638541728 * b, 3);
    const s = Math.pow(L - 0.0894841775 * a - 1.291485548 * b, 3);
    return [
      4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
      -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
      -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
    ];
  }

  function rgbToOklch(rgb) {
    const { L, a, b } = rgbToOklab(rgb);
    const C = Math.hypot(a, b);
    let h = (Math.atan2(b, a) * 180) / Math.PI;
    if (h < 0) h += 360;
    return { L, C, h, a, b };
  }

  /** OKLCH -> sRGB; außerhalb des Gamuts wird die Chroma reduziert (Farbton bleibt). */
  function oklchToRgb(L, C, h) {
    L = clamp(L, 0, 1);
    const hr = (h * Math.PI) / 180;
    const cos = Math.cos(hr), sin = Math.sin(hr);
    const attempt = (c) => {
      const lin = oklabToLinearRgb(L, c * cos, c * sin);
      return lin.every((v) => v >= -1e-4 && v <= 1 + 1e-4) ? lin : null;
    };
    let lin = attempt(C);
    if (!lin) {
      let lo = 0, hi = C;
      for (let i = 0; i < 20; i++) {
        const mid = (lo + hi) / 2;
        if (attempt(mid)) lo = mid;
        else hi = mid;
      }
      lin = attempt(lo) || oklabToLinearRgb(L, 0, 0);
    }
    return {
      r: clamp(Math.round(fromLinear(clamp(lin[0], 0, 1))), 0, 255),
      g: clamp(Math.round(fromLinear(clamp(lin[1], 0, 1))), 0, 255),
      b: clamp(Math.round(fromLinear(clamp(lin[2], 0, 1))), 0, 255),
    };
  }

  function rgbToHsl({ r, g, b }) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    if (max === min) return { h: 0, s: 0, l };
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h;
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    return { h: h * 60, s, l };
  }

  // ---------------------------------------------------------------- Kontrast

  function luminance({ r, g, b }) {
    const f = (c) => toLinear(c);
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  }

  /** WCAG-Kontrastverhältnis zweier Hex-Farben. */
  function contrast(hexA, hexB) {
    const a = parseHex(hexA), b = parseHex(hexB);
    if (!a || !b) return 1;
    const la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  // --------------------------------------------------------------- Remapping

  // Helligkeit zählt beim Zuordnen weniger als Farbton/Sättigung, damit z.B.
  // dunkle Hover-Varianten der Primärfarbe noch der Primärfarbe zugeordnet werden.
  const L_WEIGHT = 0.55;
  const MAX_DISTANCE = 0.16;
  const NEUTRAL_CHROMA = 0.04;

  function distance(p, q) {
    const dL = (p.L - q.L) * L_WEIGHT;
    return Math.hypot(dL, p.a - q.a, p.b - q.b);
  }

  function shiftColor(src, anchor, target) {
    const L = src.L + (target.L - anchor.L);
    let C, h;
    if (target.C < 0.012) {
      // Ziel ist (fast) grau: Farbigkeit abbauen statt zufälligen Farbton erzeugen.
      C = Math.max(0, src.C - anchor.C) * 0.5;
      h = src.h;
    } else if (anchor.C < NEUTRAL_CHROMA) {
      // Neutraler Anker (Hintergründe, Rahmen): Tönung des Ziels übernehmen.
      C = Math.max(0, src.C - anchor.C + target.C);
      h = src.C < 0.012 ? target.h : src.h + (target.h - anchor.h);
    } else {
      C = src.C * (target.C / anchor.C);
      h = src.C < 0.012 ? target.h : src.h + (target.h - anchor.h);
    }
    return oklchToRgb(L, C, ((h % 360) + 360) % 360);
  }

  /**
   * Erstellt einen Mapper für ein Theme. Rückgabe: Funktion hex6 -> "r, g, b"
   * oder null, wenn die Farbe unverändert bleiben soll.
   */
  function createMapper(colors) {
    const anchors = SKT.ROLES.map((role) => {
      const a = parseHex(ORIGINAL[role]);
      const t = parseHex((colors && colors[role]) || ORIGINAL[role]) || a;
      return { role, anchor: rgbToOklch(a), target: rgbToOklch(t), targetRgb: t, identity: toHex(a) === toHex(t) };
    });

    return function map(hex6) {
      const rgb = parseHex(hex6);
      if (!rgb) return null;
      const src = rgbToOklch(rgb);
      let best = null, bestD = Infinity;
      for (const entry of anchors) {
        const d = distance(src, entry.anchor);
        if (d < bestD) { bestD = d; best = entry; }
      }
      if (!best || bestD > MAX_DISTANCE || best.identity) return null;
      const out = bestD < 1e-6 ? best.targetRgb : shiftColor(src, best.anchor, best.target);
      const hex = toHex(out);
      if (hex === toHex(rgb)) return null;
      return `${out.r}, ${out.g}, ${out.b}`;
    };
  }

  /** Liefert {hex6: "r, g, b"} nur für Farben, die sich durch das Theme ändern. */
  function buildPalette(colors, hexList) {
    const map = createMapper(colors);
    const palette = {};
    for (const hex of hexList) {
      const v = map(hex);
      if (v) palette[hex] = v;
    }
    return palette;
  }

  /** Farbtonverschiebung (HSL, Grad) der Primärfarbe – für hue-rotate() auf Bildern. */
  function primaryHueShift(colors) {
    const a = parseHex(ORIGINAL.primary);
    const t = parseHex(colors && colors.primary);
    if (!t) return 0;
    const ha = rgbToHsl(a), ht = rgbToHsl(t);
    if (ht.s < 0.08) return 0;
    let d = ht.h - ha.h;
    if (d > 180) d -= 360;
    if (d < -180) d += 360;
    return d;
  }

  /** Mischt zwei Hex-Farben (t = 0..1) in OKLab. */
  function mix(hexA, hexB, t) {
    const a = rgbToOklab(parseHex(hexA)), b = rgbToOklab(parseHex(hexB));
    const L = a.L + (b.L - a.L) * t, A = a.a + (b.a - a.a) * t, B = a.b + (b.b - a.b) * t;
    const C = Math.hypot(A, B);
    let h = (Math.atan2(B, A) * 180) / Math.PI;
    if (h < 0) h += 360;
    return toHex(oklchToRgb(L, C, h));
  }

  Object.assign(SKT, {
    parseHex,
    toHex,
    normalizeHex,
    rgbToOklch,
    oklchToRgb,
    contrast,
    createMapper,
    buildPalette,
    primaryHueShift,
    mix,
  });
})(typeof globalThis !== 'undefined' ? globalThis : this);
